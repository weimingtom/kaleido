//package kurumi;

#if os(OSX) || os(iOS)
import Darwin
#elseif os(Linux)
import GLibc
#endif
import Foundation

public class ClassType {
    //FIXME:remove typeof
    //TODO:need reimplementation->search for stub replacement
    //TODO:not implemented->search for empty stub
    //TODO:not sync
    private static let DONNOT_USE_REIMPLEMENT:Bool = false
    
    //char //---
    public static let TYPE_CHAR:Int = 1
    //FIXME:TYPE_INT equal TYPE_INT32
    //int //typeof(int/*uint*/)
    public static let TYPE_INT:Int = 2
    //Double, Lua_Number
    public static let TYPE_DOUBLE:Int = 3
    // UInt32 Instruction //---
    public static let TYPE_LONG:Int = 4
    //LG
    public static let TYPE_LG:Int = 5
    //FilePtr
    public static let TYPE_FILEPTR:Int = 6
    //TValue; //---
    public static let TYPE_TVALUE:Int = 7
    //CClosure
    public static let TYPE_CCLOSURE:Int = 8
    //LClosure
    public static let TYPE_LCLOSURE:Int = 9
    //Table
    public static let TYPE_TABLE:Int = 10
    //GCObjectRef
    public static let TYPE_GCOBJECTREF:Int = 11
    //TString
    public static let TYPE_TSTRING:Int = 12
    //Node
    public static let TYPE_NODE:Int = 13
    //Udata
    public static let TYPE_UDATA:Int = 14
    //lua_State
    public static let TYPE_LUA_STATE:Int = 15
    //CallInfo //---
    public static let TYPE_CALLINFO:Int = 16
    //Proto //---
    public static let TYPE_PROTO:Int = 17
    //LocVar
    public static let TYPE_LOCVAR:Int = 18
    //---
    //Closure
    public static let TYPE_CLOSURE:Int = 19
    //UpVal
    public static let TYPE_UPVAL:Int = 20
    //Int32
    public static let TYPE_INT32:Int = 21
    //GCObject
    public static let TYPE_GCOBJECT:Int = 22
    //---
    public static let TYPE_CHARPTR:Int = 23
    
    private var type:Int = 0

    public init(type:Int) {
        self.type = type
    }
    
    public func GetTypeID() -> Int {
        return self.type
    }
    
    
    public func GetTypeString() -> String! {
        if (ClassType.DONNOT_USE_REIMPLEMENT) {
            return GetTypeString_csharp();
        }
        else {
            //TODO:not sync
            var result:String! = nil
            if (type == ClassType.TYPE_CHAR) {
                result = "Char"
            }
            else if (type == ClassType.TYPE_INT) {
                result = "Int"
            }
            else if (type == ClassType.TYPE_DOUBLE) {
                result = "Double"
            }
            else if (type == ClassType.TYPE_LONG) {
                result = "Int64" //FIXME:
            }
            else if (type == ClassType.TYPE_LG) {
                result = "LG"
            }
            else if (type == ClassType.TYPE_FILEPTR) {
                result = "FilePtr"
            }
            else if (type == ClassType.TYPE_TVALUE) {
                result = "TValue"
            }
            else if (type == ClassType.TYPE_CCLOSURE) {
                result = "CClosure"
            }
            else if (type == ClassType.TYPE_LCLOSURE) {
                result = "LClosure"
            }
            else if (type == ClassType.TYPE_TABLE) {
                result = "Table"
            }
            else if (type == ClassType.TYPE_GCOBJECTREF) {
                result = "GCObjectRef"
            }
            else if (type == ClassType.TYPE_TSTRING) {
                result = "TString"
            }
            else if (type == ClassType.TYPE_NODE) {
                result = "Node"
            }
            else if (type == ClassType.TYPE_UDATA) {
                result = "Udata"
            }
            else if (type == ClassType.TYPE_LUA_STATE) {
                result = "lua_State"
            }
            else if (type == ClassType.TYPE_CALLINFO) {
                result = "CallInfo"
            }
            else if (type == ClassType.TYPE_PROTO) {
                result = "Proto"
            }
            else if (type == ClassType.TYPE_LOCVAR) {
                result = "LocVar"
            }
            else if (type == ClassType.TYPE_CLOSURE) {
                result = "Closure"
            }
            else if (type == ClassType.TYPE_UPVAL) {
                result = "UpVal"
            }
            else if (type == ClassType.TYPE_INT32) {
                result = "Int32" //FIXME:
            }
            else if (type == ClassType.TYPE_GCOBJECT) {
                result = "GCObject"
            }
            else if (type == ClassType.TYPE_CHARPTR) {
                result = "CharPtr"
            }
            //return null;
            if (result == nil) {
                return "unknown type"
            }
            else {
                return result
            }
        }
    }
    
    
    public func Alloc() -> Any? {
//        if (DONNOT_USE_REIMPLEMENT) {
//        return Alloc_csharp();
//        }
//        else {
//        Object result = null;
//        //FIXME:
//        //return System.Activator.CreateInstance(this.GetOriginalType());
//        if (type == TYPE_CHAR) {
//        result = new Character('\0');
//        }
//        else if (type == TYPE_INT) {
//        result = new Integer(0);
//        }
//        else if (type == TYPE_DOUBLE) {
//        result = new Double(0);
//        }
//        else if (type == TYPE_LONG) {
//        result = new Long(0); //FIXME:
//        }
//        else if (type == TYPE_LG) {
//        result = new LuaState.LG();
//        }
//        else if (type == TYPE_FILEPTR) {
//        result = new LuaIOLib.FilePtr();
//        }
//        else if (type == TYPE_TVALUE) {
//        result = new LuaObject.TValue();
//        }
//        else if (type == TYPE_CCLOSURE) {
//        throw new RuntimeException("alloc CClosure error");
//        //return new CClosure(null);
//        }
//        else if (type == TYPE_LCLOSURE) {
//        throw new RuntimeException("alloc LClosure error");
//        //return new LClosure(null);
//        }
//        else if (type == TYPE_TABLE) {
//        result = new LuaObject.Table();
//        }
//        else if (type == TYPE_GCOBJECTREF) {
//        //return null; //FIXME:interface!!!
//        throw new RuntimeException("alloc GCObjectRef error");
//        }
//        else if (type == TYPE_TSTRING) {
//        result = new LuaObject.TString();
//        }
//        else if (type == TYPE_NODE) {
//        result = new LuaObject.Node();
//        }
//        else if (type == TYPE_UDATA) {
//        result = new LuaObject.Udata();
//        }
//        else if (type == TYPE_LUA_STATE) {
//        result = new LuaState.lua_State();
//        }
//        else if (type == TYPE_CALLINFO) {
//        result = new LuaState.CallInfo();
//        }
//        else if (type == TYPE_PROTO) {
//        result = new LuaObject.Proto();
//        }
//        else if (type == TYPE_LOCVAR) {
//        result = new LuaObject.LocVar();
//        }
//        else if (type == TYPE_CLOSURE) {
//        result = new LuaObject.Closure();
//        }
//        else if (type == TYPE_UPVAL) {
//        result = new LuaObject.UpVal();
//        }
//        else if (type == TYPE_INT32) {
//        result = new Integer(0); //FIXME:
//        }
//        else if (type == TYPE_GCOBJECT) {
//        result = new LuaState.GCObject();
//        }
//        else if (type == TYPE_CHARPTR) {
//        result = new CLib.CharPtr();
//        }
//        //return null;
//        if (result == null) {
//        throw new RuntimeException("alloc unknown type error");
//        }
//        else {
//        //Debug.WriteLine("alloc " + result.GetType().ToString());
//        return result;
//        }
//        }
        return nil
    }
    
    
    public func CanIndex() -> Bool {
        if (ClassType.DONNOT_USE_REIMPLEMENT) {
            return CanIndex_csharp();
        }
        else {
            if (type == ClassType.TYPE_CHAR) {
                return false;
            }
            //else if (type == TYPE_BYTE)
            //{
            //    return false;
            //}
            else if (type == ClassType.TYPE_INT) {
                return false;
            }
            else if (type == ClassType.TYPE_LOCVAR) {
                return false;
            }
            else if (type == ClassType.TYPE_LONG) {
                return false;
            }
            else {
                return true;
            }
        }
    }
    
    public func GetUnmanagedSize() -> Int {
        if (ClassType.DONNOT_USE_REIMPLEMENT) {
            return GetUnmanagedSize_csharp();
        }
        else {
            var result:Int = -1;
            if (type == ClassType.TYPE_LG) {
                result = 376;
            }
            //else if (type == TYPE_GLOBAL_STATE)
            //{
            //    result = 228;
            //}
            else if (type == ClassType.TYPE_CALLINFO) {
                result = 24;
            }
            else if (type == ClassType.TYPE_TVALUE) {
                result = 16;
            }
            else if (type == ClassType.TYPE_TABLE) {
                result = 32;
            }
            else if (type == ClassType.TYPE_NODE) {
                result = 32;
            }
            else if (type == ClassType.TYPE_GCOBJECT) {
                result = 120;
            }
            else if (type == ClassType.TYPE_GCOBJECTREF) {
                result = 4;
            }
            //else if (type == TYPE_ARRAYREF)
            //{
            //    result = 4;
            //}
            else if (type == ClassType.TYPE_CLOSURE) {
                //FIXME: this is zero
                result = 0; // handle this one manually in the code
            }
            else if (type == ClassType.TYPE_PROTO) {
                result = 76
            }
            //else if (type == TYPE_LUAL_REG)
            //{
            //    result = 8;
            //}
            //else if (type == TYPE_LUAL_BUFFER)
            //{
            //    result = 524;
            //}
            else if (type == ClassType.TYPE_LUA_STATE) {
                result = 120
            }
            //else if (type == TYPE_LUA_DEBUG)
            //{
            //    result = 100;
            //}
            //else if (type == TYPE_CALLS)
            //{
            //    result = 8;
            //}
            //else if (type == TYPE_LOADF)
            //{
            //    result = 520;
            //}
            //else if (type == TYPE_LOADS)
            //{
            //    result = 8;
            //}
            //else if (type == TYPE_LUA_LONGJMP)
            //{
            //   result = 72;
            //}
            //else if (type == TYPE_SPARSER)
            //{
            //    result = 20;
            //}
            //else if (type == TYPE_TOKEN)
            //{
            //    result = 16;
            //}
            //else if (type == TYPE_LEXSTATE)
            //{
            //    result = 52;
            //}
            //else if (type == TYPE_FUNCSTATE)
            //{
            //    result = 572;
            //}
            //else if (type == TYPE_GCHEADER)
            //{
            //    result = 8;
            //}
            else if (type == ClassType.TYPE_TVALUE) {
                result = 16
            }
            else if (type == ClassType.TYPE_TSTRING) {
                result = 16
            }
            else if (type == ClassType.TYPE_LOCVAR) {
                result = 12
            }
            else if (type == ClassType.TYPE_UPVAL) {
                result = 32
            }
            else if (type == ClassType.TYPE_CCLOSURE) {
                result = 40
            }
            else if (type == ClassType.TYPE_LCLOSURE) {
                result = 24
            }
            //else if (type == TYPE_TKEY)
            //{
            //    result = 16;
            //}
            //else if (type == TYPE_CONSCONTROL)
            //{
            //    result = 40;
            //}
            //else if (type == TYPE_LHS_ASSIGN)
            //{
            //    result = 32;
            //}
            //else if (type == TYPE_EXPDESC)
            //{
            //    result = 24;
            //}
            //else if (type == TYPE_UPVALDESC)
            //{
            //    result = 2;
            //}
            //else if (type == TYPE_BLOCKCNT)
            //{
            //    result = 12;
            //}
            //else if (type == TYPE_ZIO)
            //{
            //    result = 20;
            //}
            //else if (type == TYPE_MBUFFER)
            //{
            //    result = 12;
            //}
            //else if (type == TYPE_LOADSTATE)
            //{
            //    result = 16;
            //}
            //else if (type == TYPE_MATCHSTATE)
            //{
            //    result = 272;
            //}
            //else if (type == TYPE_STRINGTABLE)
            //{
            //    result = 12;
            //}
            else if (type == ClassType.TYPE_FILEPTR) {
                result = 4
            }
            else if (type == ClassType.TYPE_UDATA) {
                result = 24
            }
            else if (type == ClassType.TYPE_CHAR) {
                result = 1
            }
            //else if (type == TYPE_UINT16)
            //{
            //    result = 2;
            //}
            //else if (type == TYPE_INT16)
            //{
            //    result = 2;
            //}
            //else if (type == TYPE_UINT32)
            //{
            //    result = 4;
            //}
            else if (type == ClassType.TYPE_INT32) {
                result = 4
            }
            else if (type == ClassType.TYPE_INT) {
                //FIXME: added, equal to TYPE_INT32
                result = 4
            }
            //else if (type == TYPE_SINGLE)
            //{
            //    result = 4;
            //}
            else if (type == ClassType.TYPE_LONG) {
                result = 8
            }
            if (result < 0) {
                assert(false, "Trying to get unknown sized of unmanaged type " + GetTypeString());
            }
            else {
                return result
            }
        }
    }
    
    //TODO:need reimplementation
    public func GetMarshalSizeOf() -> Int {
        if (ClassType.DONNOT_USE_REIMPLEMENT) {
            return GetMarshalSizeOf_csharp();
        }
        else {
            //new method
            return GetUnmanagedSize();
        }
    }
    
    //only byValue type
    public func ObjToBytes(b:Any!) -> [UInt8]! {
        if (ClassType.DONNOT_USE_REIMPLEMENT) {
            return ObjToBytes_csharp(b:b);
        }
        else {
            //TODO:not implemented
            return nil
            //LuaDump.DumpMem not work
            //LuaStrLib.writer not work
        }
    }
    
    //TODO:need reimplementation
    public func ObjToBytes2(b:Any!) -> [UInt8]! {
        if (ClassType.DONNOT_USE_REIMPLEMENT) {
            return ObjToBytes2_csharp(b:b);
        }
        else {
            return ObjToBytes(b:b);
        }
    }
    
    //TODO:need reimplementation
    public func bytesToObj(bytes:[UInt8]!) -> Any! {
        if (ClassType.DONNOT_USE_REIMPLEMENT) {
            return bytesToObj_csharp(bytes:bytes)
        }
        else {
            //TODO:not implemented
            return nil
            //LuaUndump.LoadMem not work
        }
    }
   
    //number of ints inside a lua_Number
    public static func GetNumInts() -> Int {
        //return sizeof(Double/*lua_Number*/) / sizeof(int); //FIXME:
        return 8 / 4
    }
    
    public static func SizeOfInt() -> Int {
        //return sizeof(int); //FIXME:
        return 4
    }

    public static func SizeOfLong() -> Int {
        //sizeof(long/*uint*/)
        //sizeof(long/*UInt32*//*Instruction*/));
        //return sizeof(long); //FIXME:
        return 8
    }
    
    public static func SizeOfDouble() -> Int {
        //sizeof(Double/*lua_Number*/)
        //return sizeof(double);//FIXME:
        return 8
    }
    
    public static func ConvertToSingle(o:Any!) -> Double {
        //return Convert.ToSingle(o); //FIXME:
        if let result:Double = Double(String(describing: o)) {
            return result
        } else {
            assert(false, "ConvertToSingle failed")
            return 0
        }
    }
    
    public static func ConvertToChar(str:String!) -> Character {
        return str.count > 0 ? str[String.Index(encodedOffset: 0)] : "\0";
    }

    public static func ConvertToInt32(str:String!) -> Int {
        if let result:Int = Int(str) {
            return result
        } else {
            assert(false, "ConvertToInt32 failed")
            return 0
        }
    }
    
    public static func ConvertToInt32(i:Int64) -> Int {
        //return Convert.ToInt32(i); //FIXME:
        return Int(i)
    }
    
    public static func ConvertToInt32_object(i:Any!) -> Int {
        //return Convert.ToInt32(i);//FIXME:
        if let result:Int = Int(String(describing: i)) {
            return result
        } else {
            assert(false, "ConvertToInt32_object failed")
            return 0
        }
    }
    
    public static func ConvertToDouble(str:String!, isSuccess:inout [Bool]!) -> Double {
        if (isSuccess != nil) {
            isSuccess[0] = true
        }
        if let result:Double = Double(str) {
            return result
        } else {
            if (isSuccess != nil) {
                isSuccess[0] = false;
            }
            return 0
        }
    }
    
    public static func isNaN(d:Double) -> Bool {
        return d.isNaN
    }
    
    public static func log2(x:Double) -> Int {
        if (DONNOT_USE_REIMPLEMENT) {
            return log2_csharp(x:x)
        }
        else {
            return Int(Darwin.log2(x))
        }
    }
    
    public static func ConvertToInt32(obj:Any!) -> Double {
        //return Convert.ToInt32(obj);//FIXME:
        if let result:Int = Int(String(describing: obj)) {
            return Double(result)
        } else {
            assert(false, "ConvertToInt32 failed")
            return 0
        }
    }

    
    public static func IsPunctuation(c:Character) -> Bool {
        if (c == "," ||
            c == "." ||
            c == ";" ||
            c == ":" ||
            c == "!" ||
            c == "?" ||
            c == "/" ||
            c == "\\" ||
            c == "\'" ||
            c == "\"") {
            return true
        } else {
            return false
        }
    }
    
    public static func IndexOfAny(str:String!, anyOf:[Character]!) -> Int {
        if (DONNOT_USE_REIMPLEMENT) {
            return IndexOfAny_csharp(str:str, anyOf:anyOf)
        }
        else {
            var index:Int = -1
            for i:Int in 0 ..< anyOf.count {
                if let index2:String.Index = str.index(of:anyOf[i]) {
                    if (index == -1) {
                        index = index2.encodedOffset
                    }
                    else {
                        if (index2.encodedOffset < index) {
                            index = index2.encodedOffset
                        }
                    }
                }
            }
            return index
        }
    }
    
    public static func Assert(condition:Bool) {
        if (DONNOT_USE_REIMPLEMENT) {
            Assert_csharp(condition:condition)
        }
        else {
            assert(condition, "Assert")
        }
    }
    
    public static func Assert(condition:Bool, message:String!) {
        if (DONNOT_USE_REIMPLEMENT) {
            Assert_csharp(condition:condition, message:message);
        }
        else {
            assert(condition, message)
        }
    }
    
    public static func processExec(strCmdLine:String!) -> Int {
        if (DONNOT_USE_REIMPLEMENT) {
            return processExec_csharp(strCmdLine:strCmdLine)
        }
        else {
            //TODO:not implemented
            return 0
            //LuaOSLib.os_execute
        }
    }
    
    //object[] to T[]
    public func ToArray(arr:[Any]!) -> Any! {
        if (ClassType.DONNOT_USE_REIMPLEMENT) {
            return ToArray_csharp(arr:arr)
        }
        else {
            //TODO:not implemented
            return nil
            //LuaUndump
        }
    }

    public static func GetBytes(d:Double) -> [Int]! {
        //FIXME:
        var count:Int = 8
        var value:Double = d
        var arr:[UInt8] = withUnsafeBytes(of: &value) { Array($0) }
        var result:[Int] = [Int](repeating: 0, count: 8)
        if (arr.count < 8) {
            count = arr.count
        }
        for i:Int in 0 ..< count {
            result[i] = Int(arr[i])
        }
        return result
    }
    
    //--------------------------------
    //csharp only implementations
    //--------------------------------

    //using System.Runtime.Serialization.Formatters.Binary;
    private func ObjToBytes2_csharp(b:Any!) -> [UInt8]! {
        return nil;
    }
    
    private func GetMarshalSizeOf_csharp() -> Int {
        return 0
    }
    
    private func bytesToObj_csharp(bytes:[UInt8]!) -> Any! {
        return nil;
    }
    
    private func ObjToBytes_csharp(b:Any!) -> [UInt8]! {
        return nil
    }
    
    private static func processExec_csharp(strCmdLine:String!) -> Int {
        return 0
    }
    
//    private Object Alloc_csharp() {
//        return null;
//    }
    
    private static func Assert_csharp(condition:Bool) {
    
    }
    
    private static func Assert_csharp(condition:Bool, message:String!) {
    
    }
    
//    private java.lang.Class GetOriginalType_csharp() {
//        return null;
//    }
    
    private func ToArray_csharp(arr:[Any]!) -> Any! {
        return nil
    }
    
    private func CanIndex_csharp() -> Bool {
        return false
    }
    
    private func GetTypeString_csharp() -> String! {
        return nil
    }
    
    private func GetUnmanagedSize_csharp() -> Int {
        return 0
    }
    
    public static func IndexOfAny_csharp(str:String!, anyOf:[Character]!) -> Int {
        return 0;
    }
    
    public static func log2_csharp(x:Double) -> Int {
        return 0;
    }
}
