//package kurumi;

//
// ** $Id: lapi.c,v 2.55.1.5 2008/07/04 18:41:18 roberto Exp $
// ** Lua API
// ** See Copyright Notice in lua.h
//

//using lu_mem = System.UInt32;
//using TValue = Lua.TValue;
//using StkId = Lua.TValue;
//using lua_Integer = System.Int32;
//using lua_Number = System.Double;
//using ptrdiff_t = System.Int32;

public class LuaAPI {
    public static let lua_ident:String = "$Lua: " + Lua.LUA_RELEASE + " " + Lua.LUA_COPYRIGHT + " $\n" + "$Authors: " + Lua.LUA_AUTHORS + " $\n" + "$URL: www.lua.org $\n"
    
    public static func api_checknelems(L:lua_State!, n:Int) {
//        LuaLimits.api_check(L, n <= LuaObject.TValue.minus(L.top, L.base_));
    }
    
    public static func api_checkvalidindex(L:lua_State!, i:TValue!) { //StkId
//        LuaLimits.api_check(L, i != LuaObject.luaO_nilobject);
    }
    
    public static func api_incr_top(L:lua_State!) {
//        LuaLimits.api_check(L, LuaObject.TValue.lessThan(L.top, L.ci.top));
//        LuaObject.TValue[] top = new LuaObject.TValue[1];
//        top[0] = L.top;
//        //StkId
//        LuaObject.TValue.inc(top); //ref
//        L.top = top[0];
    }
    
    private static func index2adr(L:lua_State!, idx:Int) -> TValue! {
//        if (idx > 0) {
//        LuaObject.TValue o = LuaObject.TValue.plus(L.base_, (idx - 1));
//        LuaLimits.api_check(L, idx <= LuaObject.TValue.minus(L.ci.top, L.base_));
//        if (LuaObject.TValue.greaterEqual(o, L.top)) {
//        return LuaObject.luaO_nilobject;
//        }
//        else {
//        return o;
//        }
//        }
//        else if (idx > Lua.LUA_REGISTRYINDEX) {
//        LuaLimits.api_check(L, idx != 0 && -idx <= LuaObject.TValue.minus(L.top, L.base_));
//        return LuaObject.TValue.plus(L.top, idx);
//        }
//        else {
//        switch (idx) {
//        // pseudo-indices
//        case Lua.LUA_REGISTRYINDEX: {
//        return LuaState.registry(L);
//        }
//        case Lua.LUA_ENVIRONINDEX: {
//        LuaObject.Closure func = LuaState.curr_func(L);
//        LuaObject.sethvalue(L, L.env, func.c.getEnv());
//        return L.env;
//        }
//        case Lua.LUA_GLOBALSINDEX: {
//        return LuaState.gt(L);
//        }
//        default: {
//        LuaObject.Closure func = LuaState.curr_func(L);
//        idx = Lua.LUA_GLOBALSINDEX - idx;
//        return (idx <= func.c.getNupvalues()) ? func.c.upvalue[idx-1] : (LuaObject.TValue)LuaObject.luaO_nilobject;
//        }
//        }
//        }
        return nil
    }
    
    private static func getcurrenv(L:lua_State!) -> Table! {
//        if (L.ci == L.base_ci[0]) { // no enclosing function?
//        return LuaObject.hvalue(LuaState.gt(L)); // use global table as environment
//        }
//        else {
//        LuaObject.Closure func = LuaState.curr_func(L);
//        return func.c.getEnv();
//        }
        return nil
    }
    
    public static func luaA_pushobject(L:lua_State!, o:TValue!) {
//        LuaObject.setobj2s(L, L.top, o);
//        api_incr_top(L);
    }
    
    public static func lua_checkstack(L:lua_State!, size:Int) -> Int {
//        int res = 1;
//        LuaLimits.lua_lock(L);
//        if (size > LuaConf.LUAI_MAXCSTACK || (LuaObject.TValue.minus(L.top, L.base_) + size) > LuaConf.LUAI_MAXCSTACK) {
//        res = 0; // stack overflow
//        }
//        else if (size > 0) {
//        LuaDo.luaD_checkstack(L, size);
//        if (LuaObject.TValue.lessThan(L.ci.top, LuaObject.TValue.plus(L.top, size))) {
//        L.ci.top = LuaObject.TValue.plus(L.top, size);
//        }
//        }
//        LuaLimits.lua_unlock(L);
//        return res;
        return 0
    }
    
    public static func lua_xmove(from:lua_State!, to:lua_State!, n:Int) {
//        int i;
//        if (from == to) {
//        return;
//        }
//        LuaLimits.lua_lock(to);
//        api_checknelems(from, n);
//        LuaLimits.api_check(from, LuaState.G(from) == LuaState.G(to));
//        LuaLimits.api_check(from, LuaObject.TValue.minus(to.ci.top, to.top) >= n);
//        from.top = LuaObject.TValue.minus(from.top, n);
//        for (i = 0; i < n; i++) {
//        LuaObject.TValue[] top = new LuaObject.TValue[1];
//        top[0] = to.top;
//        LuaObject.TValue ret = LuaObject.TValue.inc(top); //ref - StkId
//        to.top = top[0];
//        LuaObject.setobj2s(to, ret, LuaObject.TValue.plus(from.top, i));
//        }
//        LuaLimits.lua_unlock(to);
    }
    
    public static func lua_setlevel(from:lua_State!, to:lua_State!) {
//        to.nCcalls = from.nCcalls;
    }
    
    public static func lua_atpanic(L:lua_State!, panicf:lua_CFunction!) -> lua_CFunction! {
//        Lua.lua_CFunction old;
//        LuaLimits.lua_lock(L);
//        old = LuaState.G(L).panic;
//        LuaState.G(L).panic = panicf;
//        LuaLimits.lua_unlock(L);
//        return old;
        return nil
    }
    
    public static func lua_newthread(L:lua_State!) -> lua_State! {
//        LuaState.lua_State L1;
//        LuaLimits.lua_lock(L);
//        LuaGC.luaC_checkGC(L);
//        L1 = LuaState.luaE_newthread(L);
//        LuaObject.setthvalue(L, L.top, L1);
//        api_incr_top(L);
//        LuaLimits.lua_unlock(L);
//        LuaConf.luai_userstatethread(L, L1);
//        return L1;
        return nil
    }
    
    //
    //         ** basic stack manipulation
    //
    public static func lua_gettop(L:lua_State!) -> Int {
//        return LuaLimits.cast_int(LuaObject.TValue.minus(L.top, L.base_));
        return 0
    }
    
    public static func lua_settop(L:lua_State!, idx:Int) {
//        LuaLimits.lua_lock(L);
//        if (idx >= 0) {
//        LuaLimits.api_check(L, idx <= LuaObject.TValue.minus(L.stack_last, L.base_));
//        while (LuaObject.TValue.lessThan(L.top, LuaObject.TValue.plus(L.base_, idx))) {
//        LuaObject.TValue[] top = new LuaObject.TValue[1];
//        top[0] = L.top;
//        LuaObject.setnilvalue(LuaObject.TValue.inc(top)); //ref - StkId
//        L.top = top[0];
//        }
//        L.top = LuaObject.TValue.plus(L.base_, idx);
//        }
//        else {
//        LuaLimits.api_check(L, -(idx + 1) <= LuaObject.TValue.minus(L.top, L.base_));
//        L.top = LuaObject.TValue.plus(L.top, idx+1); // `subtract' index (index is negative)
//        }
//        LuaLimits.lua_unlock(L);
    }
    
    public static func lua_remove(L:lua_State!, idx:Int) {
//        LuaObject.TValue p; //StkId
//        LuaLimits.lua_lock(L);
//        p = index2adr(L, idx);
//        api_checkvalidindex(L, p);
//        while (LuaObject.TValue.lessThan((p = p.get(1)), L.top)) {
//        LuaObject.setobjs2s(L, LuaObject.TValue.minus(p, 1), p);
//        }
//        LuaObject.TValue[] top = new LuaObject.TValue[1];
//        top[0] = L.top;
//        //StkId
//        LuaObject.TValue.dec(top); //ref
//        L.top = top[0];
//        LuaLimits.lua_unlock(L);
    }
    
    public static func lua_insert(L:lua_State!, idx:Int) {
//        LuaObject.TValue p; //StkId
//        LuaObject.TValue[] q = new LuaObject.TValue[1]; //StkId
//        q[0] = new LuaObject.TValue();
//        LuaLimits.lua_lock(L);
//        p = index2adr(L, idx);
//        api_checkvalidindex(L, p);
//        for (q[0] = L.top; LuaObject.TValue.greaterThan(q[0], p); LuaObject.TValue.dec(q)) { //ref - StkId
//        LuaObject.setobjs2s(L, q[0], LuaObject.TValue.minus(q[0], 1));
//        }
//        LuaObject.setobjs2s(L, p, L.top);
//        LuaLimits.lua_unlock(L);
    }
    
    public static func lua_replace(L:lua_State!, idx:Int) {
//        LuaObject.TValue o; //StkId
//        LuaLimits.lua_lock(L);
//        // explicit test for incompatible code
//        if (idx == Lua.LUA_ENVIRONINDEX && L.ci == L.base_ci[0]) {
//        LuaDebug.luaG_runerror(L, CLib.CharPtr.toCharPtr("no calling environment"));
//        }
//        api_checknelems(L, 1);
//        o = index2adr(L, idx);
//        api_checkvalidindex(L, o);
//        if (idx == Lua.LUA_ENVIRONINDEX) {
//        LuaObject.Closure func = LuaState.curr_func(L);
//        LuaLimits.api_check(L, LuaObject.ttistable(LuaObject.TValue.minus(L.top, 1)));
//        func.c.setEnv(LuaObject.hvalue(LuaObject.TValue.minus(L.top, 1)));
//        LuaGC.luaC_barrier(L, func, LuaObject.TValue.minus(L.top, 1));
//        }
//        else {
//        LuaObject.setobj(L, o, LuaObject.TValue.minus(L.top, 1));
//        if (idx < Lua.LUA_GLOBALSINDEX) { // function upvalue?
//        LuaGC.luaC_barrier(L, LuaState.curr_func(L), LuaObject.TValue.minus(L.top, 1));
//        }
//        }
//        LuaObject.TValue[] top = new LuaObject.TValue[1];
//        top[0] = L.top;
//        //StkId
//        LuaObject.TValue.dec(top); //ref
//        L.top = top[0];
//        LuaLimits.lua_unlock(L);
    }
    
    public static func lua_pushvalue(L:lua_State!, idx:Int) {
//        LuaLimits.lua_lock(L);
//        LuaObject.setobj2s(L, L.top, index2adr(L, idx));
//        api_incr_top(L);
//        LuaLimits.lua_unlock(L);
    }
    
    //
    //         ** access functions (stack . C)
    //
    public static func lua_type(L:lua_State!, idx:Int) -> Int {
//        LuaObject.TValue o = index2adr(L, idx); //StkId
//        return (o == LuaObject.luaO_nilobject) ? Lua.LUA_TNONE : LuaObject.ttype(o);
        return 0
    }
    
    
    public static func lua_typename(L:lua_State!, t:Int) -> CharPtr! {
//        //UNUSED(L);
//        return (t == Lua.LUA_TNONE) ? CLib.CharPtr.toCharPtr("no value") : LuaTM.luaT_typenames[t];
        return nil
    }
    
    public static func lua_iscfunction(L:lua_State!, idx:Int) -> Bool {
//        LuaObject.TValue o = index2adr(L, idx); //StkId
//        return LuaObject.iscfunction(o);
        return false
    }
    
    public static func lua_isnumber(L:lua_State!, idx:Int) -> Int {
//        LuaObject.TValue n = new LuaObject.TValue();
//        LuaObject.TValue o = index2adr(L, idx);
//        LuaObject.TValue[] o_ref = new LuaObject.TValue[1];
//        o_ref[0] = o;
//        int ret = LuaVM.tonumber(o_ref, n); //ref
//        o = o_ref[0];
//        return ret;
        return 0
    }
    
    public static func lua_isstring(L:lua_State!, idx:Int) -> Int {
//        int t = lua_type(L, idx);
//        return (t == Lua.LUA_TSTRING || t == Lua.LUA_TNUMBER) ? 1 : 0;
        return 0
    }
    
    public static func lua_isuserdata(L:lua_State!, idx:Int) -> Int {
//        LuaObject.TValue o = index2adr(L, idx);
//        return (LuaObject.ttisuserdata(o) || LuaObject.ttislightuserdata(o)) ? 1 : 0;
        return 0
    }
    
    public static func lua_rawequal(L:lua_State!, index1:Int, index2:Int) -> Int {
//        LuaObject.TValue o1 = index2adr(L, index1); //StkId
//        LuaObject.TValue o2 = index2adr(L, index2); //StkId
//        return (o1 == LuaObject.luaO_nilobject || o2 == LuaObject.luaO_nilobject) ? 0 : LuaObject.luaO_rawequalObj(o1, o2);
        return 0
    }
    
    public static func lua_equal(L:lua_State!, index1:Int, index2:Int) -> Int {
//        LuaObject.TValue o1, o2; //StkId
//        int i;
//        LuaLimits.lua_lock(L); // may call tag method
//        o1 = index2adr(L, index1);
//        o2 = index2adr(L, index2);
//        i = (o1 == LuaObject.luaO_nilobject || o2 == LuaObject.luaO_nilobject) ? 0 : LuaVM.equalobj(L, o1, o2);
//        LuaLimits.lua_unlock(L);
//        return i;
        return 0
    }
    
    public static func lua_lessthan(L:lua_State!, index1:Int, index2:Int) -> Int {
//        LuaObject.TValue o1, o2; //StkId
//        int i;
//        LuaLimits.lua_lock(L); // may call tag method
//        o1 = index2adr(L, index1);
//        o2 = index2adr(L, index2);
//        i = (o1 == LuaObject.luaO_nilobject || o2 == LuaObject.luaO_nilobject) ? 0 : LuaVM.luaV_lessthan(L, o1, o2);
//        LuaLimits.lua_unlock(L);
//        return i;
        return 0
    }
    
    public static func lua_tonumber(L:lua_State!, idx:Int) -> Double { //lua_Number
//        LuaObject.TValue n = new LuaObject.TValue();
//        LuaObject.TValue o = index2adr(L, idx);
//        LuaObject.TValue[] o_ref = new LuaObject.TValue[1];
//        o_ref[0] = o;
//        int ret = LuaVM.tonumber(o_ref, n); //ref
//        o = o_ref[0];
//        if (ret != 0) {
//        return LuaObject.nvalue(o);
//        }
//        else {
//        return 0;
//        }
        return 0
    }
    
    public static func lua_tointeger(L:lua_State!, idx:Int) -> Int { //lua_Integer - Int32
//        LuaObject.TValue n = new LuaObject.TValue();
//        LuaObject.TValue o = index2adr(L, idx);
//        LuaObject.TValue[] o_ref = new LuaObject.TValue[1];
//        o_ref[0] = o;
//        int ret = LuaVM.tonumber(o_ref, n); //ref
//        o = o_ref[0];
//        if (ret != 0) {
//        int[] res = new int[1]; //lua_Integer - Int32
//        double num = LuaObject.nvalue(o); //lua_Number - Double
//        LuaConf.lua_number2integer(res, num); //out
//        return res[0];
//        }
//        else {
//        return 0;
//        }
        return 0
    }
    
    public static func lua_toboolean(L:lua_State!, idx:Int) -> Int {
//        LuaObject.TValue o = index2adr(L, idx);
//        return (LuaObject.l_isfalse(o) == 0) ? 1 : 0;
        return 0
    }
    
    public static func lua_tolstring(L:lua_State!, idx:Int, len:[Int]) -> CharPtr! { //uint - out
//        LuaObject.TValue o = index2adr(L, idx); //StkId
//        if (!LuaObject.ttisstring(o)) {
//        LuaLimits.lua_lock(L); // `luaV_tostring' may create a new string
//        if (LuaVM.luaV_tostring(L, o) == 0)
//        { // conversion failed?
//        len[0] = 0;
//        LuaLimits.lua_unlock(L);
//        return null;
//        }
//        LuaGC.luaC_checkGC(L);
//        o = index2adr(L, idx); // previous call may reallocate the stack
//        LuaLimits.lua_unlock(L);
//        }
//        len[0] = LuaObject.tsvalue(o).len;
//        return LuaObject.svalue(o);
        return nil
    }
    
    public static func lua_objlen(L:lua_State!, idx:Int) -> Int { //uint
//        LuaObject.TValue o = index2adr(L, idx); //StkId
//        switch (LuaObject.ttype(o)) {
//        case Lua.LUA_TSTRING:
//        return LuaObject.tsvalue(o).len;
//        
//        case Lua.LUA_TUSERDATA:
//        return LuaObject.uvalue(o).len;
//        
//        case Lua.LUA_TTABLE:
//        return LuaTable.luaH_getn(LuaObject.hvalue(o)); //(uint)
//
//        case Lua.LUA_TNUMBER: {
//        int l; //uint
//        LuaLimits.lua_lock(L); // `luaV_tostring' may create a new string
//        l = (LuaVM.luaV_tostring(L, o) != 0 ? LuaObject.tsvalue(o).len : 0);
//        LuaLimits.lua_unlock(L);
//        return l;
//        }
//        
//        default:
//        return 0;
//        }
        return 0
    }
    
    public static func lua_tocfunction(L:lua_State!, idx:Int) -> lua_CFunction! {
//        LuaObject.TValue o = index2adr(L, idx); //StkId
//        return (!LuaObject.iscfunction(o)) ? null : LuaObject.clvalue(o).c.f;
        return nil
    }
    
    public static func lua_touserdata(L:lua_State!, idx:Int) -> Any! {
//        LuaObject.TValue o = index2adr(L, idx); //StkId
//        switch (LuaObject.ttype(o)) {
//        case Lua.LUA_TUSERDATA: {
//        return (LuaObject.rawuvalue(o).user_data);
//        }
//        case Lua.LUA_TLIGHTUSERDATA: {
//        return LuaObject.pvalue(o);
//        }
//        default: {
//        return null;
//        }
//        }
        return nil
    }
    
    public static func lua_tothread(L:lua_State!, idx:Int) -> lua_State! {
//        LuaObject.TValue o = index2adr(L, idx); //StkId
//        return (!LuaObject.ttisthread(o)) ? null : LuaObject.thvalue(o);
        return nil
    }
    
    public static func lua_topointer(L:lua_State!, idx:Int) -> Any! {
//        LuaObject.TValue o = index2adr(L, idx); //StkId
//        switch (LuaObject.ttype(o)) {
//        case Lua.LUA_TTABLE: {
//        return LuaObject.hvalue(o);
//        }
//        case Lua.LUA_TFUNCTION: {
//        return LuaObject.clvalue(o);
//        }
//        case Lua.LUA_TTHREAD: {
//        return LuaObject.thvalue(o);
//        }
//        case Lua.LUA_TUSERDATA:
//        case Lua.LUA_TLIGHTUSERDATA: {
//        return lua_touserdata(L, idx);
//        }
//        default: {
//        return null;
//        }
//        }
        return nil
    }
    
    //
    //         ** push functions (C . stack)
    //
    public static func lua_pushnil(L:lua_State!) {
//        LuaLimits.lua_lock(L);
//        LuaObject.setnilvalue(L.top);
//        api_incr_top(L);
//        LuaLimits.lua_unlock(L);
    }
    
    public static func lua_pushnumber(L:lua_State!, n:Double) { //lua_Number - Double
//        LuaLimits.lua_lock(L);
//        LuaObject.setnvalue(L.top, n);
//        api_incr_top(L);
//        LuaLimits.lua_unlock(L);
    }
    
    public static func lua_pushinteger(L:lua_State!, n:Int) { //lua_Integer - Int32
//        LuaLimits.lua_lock(L);
//        LuaObject.setnvalue(L.top, LuaLimits.cast_num(n));
//        api_incr_top(L);
//        LuaLimits.lua_unlock(L);
    }
    
    public static func lua_pushlstring(L:lua_State!, s:CharPtr!, len:Int) { //uint
//        LuaLimits.lua_lock(L);
//        LuaGC.luaC_checkGC(L);
//        LuaObject.setsvalue2s(L, L.top, LuaString.luaS_newlstr(L, s, len));
//        api_incr_top(L);
//        LuaLimits.lua_unlock(L);
    }
    
    public static func lua_pushstring(L:lua_State!, s:CharPtr!) {
//        if (CLib.CharPtr.isEqual(s, null)) {
//        lua_pushnil(L);
//        }
//        else {
//        lua_pushlstring(L, s, CLib.strlen(s)); //(uint)
//        }
    }
    
    public static func lua_pushvfstring(L:lua_State!, fmt:CharPtr!, argp:[Any]) -> CharPtr! {
//        CLib.CharPtr ret;
//        LuaLimits.lua_lock(L);
//        LuaGC.luaC_checkGC(L);
//        ret = LuaObject.luaO_pushvfstring(L, fmt, argp);
//        LuaLimits.lua_unlock(L);
//        return ret;
        return nil
    }
    
    public static func lua_pushfstring(L:lua_State!, fmt:CharPtr!) -> CharPtr! {
//        CLib.CharPtr ret;
//        LuaLimits.lua_lock(L);
//        LuaGC.luaC_checkGC(L);
//        ret = LuaObject.luaO_pushvfstring(L, fmt, null);
//        LuaLimits.lua_unlock(L);
//        return ret;
        return nil
    }
    
    public static func lua_pushfstring(L:lua_State!, fmt:CharPtr!, p:Any!...) -> CharPtr! {
//        CLib.CharPtr ret;
//        LuaLimits.lua_lock(L);
//        LuaGC.luaC_checkGC(L);
//        ret = LuaObject.luaO_pushvfstring(L, fmt, p);
//        LuaLimits.lua_unlock(L);
//        return ret;
        return nil
    }
    
    public static func lua_pushcclosure(L:lua_State!, fn:lua_CFunction!, n:Int) {
//        LuaObject.Closure cl;
//        LuaLimits.lua_lock(L);
//        LuaGC.luaC_checkGC(L);
//        api_checknelems(L, n);
//        cl = LuaFunc.luaF_newCclosure(L, n, getcurrenv(L));
//        cl.c.f = fn;
//        L.top = LuaObject.TValue.minus(L.top, n);
//        while (n-- != 0) {
//        LuaObject.setobj2n(L, cl.c.upvalue[n], LuaObject.TValue.plus(L.top, n));
//        }
//        LuaObject.setclvalue(L, L.top, cl);
//        LuaLimits.lua_assert(LuaGC.iswhite(LuaState.obj2gco(cl)));
//        api_incr_top(L);
//        LuaLimits.lua_unlock(L);
    }
    
    
    public static func lua_pushboolean(L:lua_State!, b:Int) {
//        LuaLimits.lua_lock(L);
//        LuaObject.setbvalue(L.top, (b != 0) ? 1 : 0); // ensure that true is 1
//        api_incr_top(L);
//        LuaLimits.lua_unlock(L);
    }
    
    public static func lua_pushlightuserdata(L:lua_State!, p:Any!) {
//        LuaLimits.lua_lock(L);
//        LuaObject.setpvalue(L.top, p);
//        api_incr_top(L);
//        LuaLimits.lua_unlock(L);
    }
    
    public static func lua_pushthread(L:lua_State!) -> Int {
//        LuaLimits.lua_lock(L);
//        LuaObject.setthvalue(L, L.top, L);
//        api_incr_top(L);
//        LuaLimits.lua_unlock(L);
//        return (LuaState.G(L).mainthread == L) ? 1 : 0;
        return 0
    }
    
    //
    //         ** get functions (Lua . stack)
    //
    public static func lua_gettable(L:lua_State!, idx:Int) {
//        LuaObject.TValue t; //StkId
//        LuaLimits.lua_lock(L);
//        t = index2adr(L, idx);
//        api_checkvalidindex(L, t);
//        LuaVM.luaV_gettable(L, t, LuaObject.TValue.minus(L.top, 1), LuaObject.TValue.minus(L.top, 1));
//        LuaLimits.lua_unlock(L);
    }
    
    public static func lua_getfield(L:lua_State!, idx:Int, k:CharPtr!) {
//        LuaObject.TValue t; //StkId
//        LuaObject.TValue key = new LuaObject.TValue();
//        LuaLimits.lua_lock(L);
//        t = index2adr(L, idx);
//        api_checkvalidindex(L, t);
//        LuaObject.setsvalue(L, key, LuaString.luaS_new(L, k));
//        LuaVM.luaV_gettable(L, t, key, L.top);
//        api_incr_top(L);
//        LuaLimits.lua_unlock(L);
    }
    
    public static func lua_rawget(L:lua_State!, idx:Int) {
//        LuaObject.TValue t; //StkId
//        LuaLimits.lua_lock(L);
//        t = index2adr(L, idx);
//        LuaLimits.api_check(L, LuaObject.ttistable(t));
//        LuaObject.setobj2s(L, LuaObject.TValue.minus(L.top, 1), LuaTable.luaH_get(LuaObject.hvalue(t), LuaObject.TValue.minus(L.top, 1)));
//        LuaLimits.lua_unlock(L);
    }
    
    public static func lua_rawgeti(L:lua_State!, idx:Int, n:Int) {
//        LuaObject.TValue o; //StkId
//        LuaLimits.lua_lock(L);
//        o = index2adr(L, idx);
//        LuaLimits.api_check(L, LuaObject.ttistable(o));
//        LuaObject.setobj2s(L, L.top, LuaTable.luaH_getnum(LuaObject.hvalue(o), n));
//        api_incr_top(L);
//        LuaLimits.lua_unlock(L);
    }
    
    public static func lua_createtable(L:lua_State!, narray:Int, nrec:Int) {
//    LuaLimits.lua_lock(L);
//    LuaGC.luaC_checkGC(L);
//    LuaObject.sethvalue(L, L.top, LuaTable.luaH_new(L, narray, nrec));
//    api_incr_top(L);
//    LuaLimits.lua_unlock(L);
    }
    
    public static func lua_getmetatable(L:lua_State!, objindex:Int) -> Int {
//        LuaObject.TValue obj;
//        LuaObject.Table mt = null;
//        int res;
//        LuaLimits.lua_lock(L);
//        obj = index2adr(L, objindex);
//        switch (LuaObject.ttype(obj)) {
//        case Lua.LUA_TTABLE: {
//        mt = LuaObject.hvalue(obj).metatable;
//        break;
//        }
//        case Lua.LUA_TUSERDATA: {
//        mt = LuaObject.uvalue(obj).metatable;
//        break;
//        }
//        default: {
//        mt = LuaState.G(L).mt[LuaObject.ttype(obj)];
//        break;
//        }
//        }
//        if (mt == null) {
//        res = 0;
//        }
//        else {
//        LuaObject.sethvalue(L, L.top, mt);
//        api_incr_top(L);
//        res = 1;
//        }
//        LuaLimits.lua_unlock(L);
//        return res;
        return 0
    }
    
    public static func lua_getfenv(L:lua_State!, idx:Int) {
//        LuaObject.TValue o; //StkId
//        LuaLimits.lua_lock(L);
//        o = index2adr(L, idx);
//        api_checkvalidindex(L, o);
//        switch (LuaObject.ttype(o)) {
//        case Lua.LUA_TFUNCTION: {
//        LuaObject.sethvalue(L, L.top, LuaObject.clvalue(o).c.getEnv());
//        break;
//        }
//        case Lua.LUA_TUSERDATA: {
//        LuaObject.sethvalue(L, L.top, LuaObject.uvalue(o).env);
//        break;
//        }
//        case Lua.LUA_TTHREAD: {
//        LuaObject.setobj2s(L, L.top, LuaState.gt(LuaObject.thvalue(o)));
//        break;
//        }
//        default: {
//        LuaObject.setnilvalue(L.top);
//        break;
//        }
//        }
//        api_incr_top(L);
//        LuaLimits.lua_unlock(L);
    }
    
    
    //
    //         ** set functions (stack . Lua)
    //
    public static func lua_settable(L:lua_State!, idx:Int) {
//        LuaObject.TValue t; //StkId
//        LuaLimits.lua_lock(L);
//        api_checknelems(L, 2);
//        t = index2adr(L, idx);
//        api_checkvalidindex(L, t);
//        LuaVM.luaV_settable(L, t, LuaObject.TValue.minus(L.top, 2), LuaObject.TValue.minus(L.top, 1));
//        L.top = LuaObject.TValue.minus(L.top, 2); // pop index and value
//        LuaLimits.lua_unlock(L);
    }
    
    public static func lua_setfield(L:lua_State!, idx:Int, k:CharPtr!) {
//        LuaObject.TValue t; //StkId
//        LuaObject.TValue key = new LuaObject.TValue();
//        LuaLimits.lua_lock(L);
//        api_checknelems(L, 1);
//        t = index2adr(L, idx);
//        api_checkvalidindex(L, t);
//        LuaObject.setsvalue(L, key, LuaString.luaS_new(L, k));
//        LuaVM.luaV_settable(L, t, key, LuaObject.TValue.minus(L.top, 1));
//        LuaObject.TValue[] top = new LuaObject.TValue[1];
//        top[0] = L.top;
//        //StkId
//        LuaObject.TValue.dec(top); // pop value  - ref
//        L.top = top[0];
//        LuaLimits.lua_unlock(L);
    }
    
    public static func lua_rawset(L:lua_State!, idx:Int) {
//        LuaObject.TValue t; //StkId
//        LuaLimits.lua_lock(L);
//        api_checknelems(L, 2);
//        t = index2adr(L, idx);
//        LuaLimits.api_check(L, LuaObject.ttistable(t));
//        LuaObject.setobj2t(L, LuaTable.luaH_set(L, LuaObject.hvalue(t), LuaObject.TValue.minus(L.top, 2)), LuaObject.TValue.minus(L.top, 1));
//        LuaGC.luaC_barriert(L, LuaObject.hvalue(t), LuaObject.TValue.minus(L.top, 1));
//        L.top = LuaObject.TValue.minus(L.top, 2);
//        LuaLimits.lua_unlock(L);
    }
    
    public static func lua_rawseti(L:lua_State!, idx:Int, n:Int) {
//        LuaObject.TValue o; //StkId
//        LuaLimits.lua_lock(L);
//        api_checknelems(L, 1);
//        o = index2adr(L, idx);
//        LuaLimits.api_check(L, LuaObject.ttistable(o));
//        LuaObject.setobj2t(L, LuaTable.luaH_setnum(L, LuaObject.hvalue(o), n), LuaObject.TValue.minus(L.top, 1));
//        LuaGC.luaC_barriert(L, LuaObject.hvalue(o), LuaObject.TValue.minus(L.top, 1));
//        LuaObject.TValue[] top = new LuaObject.TValue[1];
//        top[0] = L.top;
//        //StkId
//        LuaObject.TValue.dec(top); //ref
//        L.top = top[0];
//        LuaLimits.lua_unlock(L);
    }
    
    public static func lua_setmetatable(L:lua_State!, objindex:Int) -> Int {
//        LuaObject.TValue obj;
//        LuaObject.Table mt;
//        LuaLimits.lua_lock(L);
//        api_checknelems(L, 1);
//        obj = index2adr(L, objindex);
//        api_checkvalidindex(L, obj);
//        if (LuaObject.ttisnil(LuaObject.TValue.minus(L.top, 1))) {
//        mt = null;
//        }
//        else {
//        LuaLimits.api_check(L, LuaObject.ttistable(LuaObject.TValue.minus(L.top, 1)));
//        mt = LuaObject.hvalue(LuaObject.TValue.minus(L.top, 1));
//        }
//        switch (LuaObject.ttype(obj)) {
//        case Lua.LUA_TTABLE: {
//        LuaObject.hvalue(obj).metatable = mt;
//        if (mt != null) {
//        LuaGC.luaC_objbarriert(L, LuaObject.hvalue(obj), mt);
//        }
//        break;
//        }
//        case Lua.LUA_TUSERDATA: {
//        LuaObject.uvalue(obj).metatable = mt;
//        if (mt != null) {
//        LuaGC.luaC_objbarrier(L, LuaObject.rawuvalue(obj), mt);
//        }
//        break;
//        }
//        default: {
//        LuaState.G(L).mt[LuaObject.ttype(obj)] = mt;
//        break;
//        }
//        }
//        LuaObject.TValue[] top = new LuaObject.TValue[1];
//        top[0] = L.top;
//        //StkId
//        LuaObject.TValue.dec(top); //ref
//        L.top = top[0];
//        LuaLimits.lua_unlock(L);
//        return 1;
        return 0
    }
    
    public static func lua_setfenv(L:lua_State!, idx:Int) -> Int {
//        LuaObject.TValue o; //StkId
//        int res = 1;
//        LuaLimits.lua_lock(L);
//        api_checknelems(L, 1);
//        o = index2adr(L, idx);
//        api_checkvalidindex(L, o);
//        LuaLimits.api_check(L, LuaObject.ttistable(LuaObject.TValue.minus(L.top, 1)));
//        switch (LuaObject.ttype(o)) {
//        case Lua.LUA_TFUNCTION: {
//        LuaObject.clvalue(o).c.setEnv(LuaObject.hvalue(LuaObject.TValue.minus(L.top, 1)));
//        break;
//        }
//        case Lua.LUA_TUSERDATA: {
//        LuaObject.uvalue(o).env = LuaObject.hvalue(LuaObject.TValue.minus(L.top, 1));
//        break;
//        }
//        case Lua.LUA_TTHREAD: {
//        LuaObject.sethvalue(L, LuaState.gt(LuaObject.thvalue(o)), LuaObject.hvalue(LuaObject.TValue.minus(L.top, 1)));
//        break;
//        }
//        default: {
//        res = 0;
//        break;
//        }
//        }
//        if (res != 0) {
//        LuaGC.luaC_objbarrier(L, LuaObject.gcvalue(o), LuaObject.hvalue(LuaObject.TValue.minus(L.top, 1)));
//        }
//        LuaObject.TValue[] top = new LuaObject.TValue[1];
//        top[0] = L.top;
//        //StkId
//        LuaObject.TValue.dec(top); //ref
//        L.top = top[0];
//        LuaLimits.lua_unlock(L);
//        return res;
        return 0
    }
    
    //
    //         ** `load' and `call' functions (run Lua code)
    //
    public static func adjustresults(L:lua_State!, nres:Int) {
//        if (nres == Lua.LUA_MULTRET && LuaObject.TValue.greaterEqual(L.top, L.ci.top)) {
//        L.ci.top = L.top;
//        }
    }
    
    public static func checkresults(L:lua_State!, na:Int, nr:Int) {
//        LuaLimits.api_check(L, (nr) == Lua.LUA_MULTRET || (LuaObject.TValue.minus(L.ci.top, L.top) >= (nr) - (na)));
    }
    
    public static func lua_call(L:lua_State!, nargs:Int, nresults:Int) {
//        LuaObject.TValue func; //StkId
//        LuaLimits.lua_lock(L);
//        api_checknelems(L, nargs+1);
//        checkresults(L, nargs, nresults);
//        func = LuaObject.TValue.minus(L.top, (nargs + 1));
//        LuaDo.luaD_call(L, func, nresults);
//        adjustresults(L, nresults);
//        LuaLimits.lua_unlock(L);
    }
}

/*
 ** Execute a protected call.
 */
public class CallS {
    /* data to `f_call' */
    public var func_:TValue! /*StkId*/
    public var nresults:Int = 0
}

extension LuaAPI {
    private static func f_call(L:lua_State!, ud:Any!) {
//        CallS c = (CallS)((ud instanceof CallS) ? ud : null);
//        LuaDo.luaD_call(L, c.func, c.nresults);
    }
}


public class f_call_delegate: Pfunc {
    public func exec(L:lua_State!, ud:Any!) {
//        f_call(L, ud);
    }
}

extension LuaAPI {
    public static func lua_pcall(L:lua_State!, nargs:Int, nresults:Int, errfunc:Int) -> Int {
//        CallS c = new CallS();
//        int status;
//        int func; //ptrdiff_t - Int32
//        LuaLimits.lua_lock(L);
//        api_checknelems(L, nargs+1);
//        checkresults(L, nargs, nresults);
//        if (errfunc == 0) {
//        func = 0;
//        }
//        else {
//        LuaObject.TValue o = index2adr(L, errfunc); //StkId
//        api_checkvalidindex(L, o);
//        func = LuaDo.savestack(L, o);
//        }
//        c.func = LuaObject.TValue.minus(L.top, (nargs + 1)); // function to be called
//        c.nresults = nresults;
//        status = LuaDo.luaD_pcall(L, new f_call_delegate(), c, LuaDo.savestack(L, c.func), func);
//        adjustresults(L, nresults);
//        LuaLimits.lua_unlock(L);
//        return status;
        return 0
    }
}

/*
 ** Execute a protected C call.
 */
public class CCallS {
    /* data to `f_Ccall' */
    public var func_:lua_CFunction!
    public var ud:Any!
}

extension LuaAPI {
    private static func f_Ccall(L:lua_State!, ud:Any!) {
//        CCallS c = (CCallS)((ud instanceof CCallS) ? ud : null);
//        LuaObject.Closure cl;
//        cl = LuaFunc.luaF_newCclosure(L, 0, getcurrenv(L));
//        cl.c.f = c.func;
//        LuaObject.setclvalue(L, L.top, cl); // push function
//        api_incr_top(L);
//        LuaObject.setpvalue(L.top, c.ud); // push only argument
//        api_incr_top(L);
//        LuaDo.luaD_call(L, LuaObject.TValue.minus(L.top, 2), 0);
    }
}

public class f_Ccall_delegate: Pfunc {
    public func exec(L:lua_State!, ud:Any!) {
//        f_Ccall(L, ud);
    }
}

extension LuaAPI {
    public static func lua_cpcall(L:lua_State!, func_:lua_CFunction!, ud:Any!) -> Int {
//        CCallS c = new CCallS();
//        int status;
//        LuaLimits.lua_lock(L);
//        c.func = func;
//        c.ud = ud;
//        status = LuaDo.luaD_pcall(L, new f_Ccall_delegate(), c, LuaDo.savestack(L, L.top), 0);
//        LuaLimits.lua_unlock(L);
//        return status;
        return 0
    }

    
    public static func lua_load(L:lua_State!, reader:lua_Reader!, data:Any!, chunkname:CharPtr!) -> Int {
//        LuaZIO.ZIO z = new LuaZIO.ZIO();
//        int status;
//        LuaLimits.lua_lock(L);
//        if (CLib.CharPtr.isEqual(chunkname, null)) {
//        chunkname = CLib.CharPtr.toCharPtr("?");
//        }
//        LuaZIO.luaZ_init(L, z, reader, data);
//        status = LuaDo.luaD_protectedparser(L, z, chunkname);
//        LuaLimits.lua_unlock(L);
//        return status;
        return 0
    }
    
    
    public static func lua_dump(L:lua_State!, writer:lua_Writer!, data:Any!) -> Int {
//        int status;
//        LuaObject.TValue o;
//        LuaLimits.lua_lock(L);
//        api_checknelems(L, 1);
//        o = LuaObject.TValue.minus(L.top, 1);
//        if (LuaObject.isLfunction(o)) {
//        status = LuaDump.luaU_dump(L, LuaObject.clvalue(o).l.p, writer, data, 0);
//        }
//        else {
//        status = 1;
//        }
//        LuaLimits.lua_unlock(L);
//        return status;
        return 0
    }
    
    public static func lua_status(L:lua_State!) -> Int {
//        return L.status;
        return 0
    }
    
    //
    //         ** Garbage-collection function
    //
    public static func lua_gc(L:lua_State!, what:Int, data:Int) -> Int {
//        int res = 0;
//        LuaState.global_State g;
//        LuaLimits.lua_lock(L);
//        g = LuaState.G(L);
//        switch (what) {
//        case Lua.LUA_GCSTOP: {
//        g.GCthreshold = LuaLimits.MAX_LUMEM;
//        break;
//        }
//        case Lua.LUA_GCRESTART: {
//        g.GCthreshold = g.totalbytes;
//        break;
//        }
//        case Lua.LUA_GCCOLLECT: {
//        LuaGC.luaC_fullgc(L);
//        break;
//        }
//        case Lua.LUA_GCCOUNT: {
//        // GC values are expressed in Kbytes: #bytes/2^10
//        res = LuaLimits.cast_int(g.totalbytes >> 10);
//        break;
//        }
//        case Lua.LUA_GCCOUNTB: {
//        res = LuaLimits.cast_int(g.totalbytes & 0x3ff);
//        break;
//        }
//        case Lua.LUA_GCSTEP: {
//        long a = ((long)data << 10); //lu_mem - UInt32 - lu_mem - UInt32
//        if (a <= g.totalbytes) {
//        g.GCthreshold = (g.totalbytes - a); //(uint)
//        }
//        else {
//        g.GCthreshold = 0;
//        }
//        while (g.GCthreshold <= g.totalbytes) {
//        LuaGC.luaC_step(L);
//        if (g.gcstate == LuaGC.GCSpause) {
//        // end of cycle?
//        res = 1; // signal it
//        break;
//        }
//        }
//        break;
//        }
//        case Lua.LUA_GCSETPAUSE: {
//        res = g.gcpause;
//        g.gcpause = data;
//        break;
//        }
//        case Lua.LUA_GCSETSTEPMUL: {
//        res = g.gcstepmul;
//        g.gcstepmul = data;
//        break;
//        }
//        default: {
//        res = -1; // invalid option
//        break;
//        }
//        }
//        LuaLimits.lua_unlock(L);
//        return res;
        return 0
    }
    
    //
    //         ** miscellaneous functions
    //
    public static func lua_error(L:lua_State!) -> Int {
//        LuaLimits.lua_lock(L);
//        api_checknelems(L, 1);
//        LuaDebug.luaG_errormsg(L);
//        LuaLimits.lua_unlock(L);
//        return 0; // to avoid warnings
        return 0
    }
    
    public static func lua_next(L:lua_State!, idx:Int) -> Int {
//        LuaObject.TValue t; //StkId
//        int more;
//        LuaLimits.lua_lock(L);
//        t = index2adr(L, idx);
//        LuaLimits.api_check(L, LuaObject.ttistable(t));
//        more = LuaTable.luaH_next(L, LuaObject.hvalue(t), LuaObject.TValue.minus(L.top, 1));
//        if (more != 0) {
//        api_incr_top(L);
//        }
//        else { // no more elements
//        LuaObject.TValue[] top = new LuaObject.TValue[1];
//        top[0] = L.top;
//        //StkId
//        LuaObject.TValue.dec(top); // remove key  - ref
//        L.top = top[0];
//        }
//        LuaLimits.lua_unlock(L);
//        return more;
        return 0
    }
    
    public static func lua_concat(L:lua_State!, n:Int) {
//        LuaLimits.lua_lock(L);
//        api_checknelems(L, n);
//        if (n >= 2) {
//        LuaGC.luaC_checkGC(L);
//        LuaVM.luaV_concat(L, n, LuaLimits.cast_int(LuaObject.TValue.minus(L.top, L.base_)) - 1); //FIXME:
//        L.top = LuaObject.TValue.minus(L.top, (n - 1));
//        }
//        else if (n == 0) {
//        // push empty string
//        LuaObject.setsvalue2s(L, L.top, LuaString.luaS_newlstr(L, CLib.CharPtr.toCharPtr(""), 0));
//        api_incr_top(L);
//        }
//        // else n == 1; nothing to do
//        LuaLimits.lua_unlock(L);
    }
    
    public static func lua_getallocf(L:lua_State!, ud:[Any]!) -> lua_Alloc! { //ref
//        Lua.lua_Alloc f;
//        LuaLimits.lua_lock(L);
//        if (ud[0] != null) {
//        ud[0] = LuaState.G(L).ud;
//        }
//        f = LuaState.G(L).frealloc;
//        LuaLimits.lua_unlock(L);
//        return f;
        return nil
    }
    
    public static func lua_setallocf(L:lua_State!, f:lua_Alloc!, ud:Any!) {
//        LuaLimits.lua_lock(L);
//        LuaState.G(L).ud = ud;
//        LuaState.G(L).frealloc = f;
//        LuaLimits.lua_unlock(L);
    }
    
    public static func lua_newuserdata(L:lua_State!, size:Int) -> Any! { //uint
//        LuaObject.Udata u;
//        LuaLimits.lua_lock(L);
//        LuaGC.luaC_checkGC(L);
//        u = LuaString.luaS_newudata(L, size, getcurrenv(L));
//        LuaObject.setuvalue(L, L.top, u);
//        api_incr_top(L);
//        LuaLimits.lua_unlock(L);
//        return u.user_data;
        return nil
    }
    
    public static func lua_newuserdata(L:lua_State!, t:ClassType!) -> Any! {
//        LuaObject.Udata u;
//        LuaLimits.lua_lock(L);
//        LuaGC.luaC_checkGC(L);
//        u = LuaString.luaS_newudata(L, t, getcurrenv(L));
//        LuaObject.setuvalue(L, L.top, u);
//        api_incr_top(L);
//        LuaLimits.lua_unlock(L);
//        return u.user_data;
        return nil
    }
    
    private static func aux_upvalue(fi:TValue!, n:Int, val:[TValue]!) -> CharPtr! { //ref - StkId
//        LuaObject.Closure f;
//        if (!LuaObject.ttisfunction(fi)) {
//        return null;
//        }
//        f = LuaObject.clvalue(fi);
//        if (f.c.getIsC() != 0) {
//        if (!(1 <= n && n <= f.c.getNupvalues())) {
//        return null;
//        }
//        val[0] = f.c.upvalue[n - 1];
//        return CLib.CharPtr.toCharPtr("");
//        }
//        else {
//        LuaObject.Proto p = f.l.p;
//        if (!(1 <= n && n <= p.sizeupvalues)) {
//        return null;
//        }
//        val[0] = f.l.upvals[n - 1].v;
//        return LuaObject.getstr(p.upvalues[n - 1]);
//        }
        return nil
    }
    
    public static func lua_getupvalue(L:lua_State!, funcindex:Int, n:Int) -> CharPtr! {
//        CLib.CharPtr name;
//        LuaObject.TValue val = new LuaObject.TValue();
//        LuaLimits.lua_lock(L);
//        LuaObject.TValue[] val_ref = new LuaObject.TValue[1];
//        val_ref[0] = val;
//        name = aux_upvalue(index2adr(L, funcindex), n, val_ref); //ref
//        val = val_ref[0];
//        if (CLib.CharPtr.isNotEqual(name, null)) {
//        LuaObject.setobj2s(L, L.top, val);
//        api_incr_top(L);
//        }
//        LuaLimits.lua_unlock(L);
//        return name;
        return nil
    }
    
    public static func lua_setupvalue(L:lua_State!, funcindex:Int, n:Int) -> CharPtr! {
//        CLib.CharPtr name;
//        LuaObject.TValue val = new LuaObject.TValue();
//        LuaObject.TValue fi; //StkId
//        LuaLimits.lua_lock(L);
//        fi = index2adr(L, funcindex);
//        api_checknelems(L, 1);
//        LuaObject.TValue[] val_ref = new LuaObject.TValue[1];
//        val_ref[0] = val;
//        name = aux_upvalue(fi, n, val_ref); //ref
//        val = val_ref[0];
//        if (CLib.CharPtr.isNotEqual(name, null)) {
//        LuaObject.TValue[] top = new LuaObject.TValue[1];
//        top[0] = L.top;
//        //StkId
//        LuaObject.TValue.dec(top); //ref
//        L.top = top[0];
//        LuaObject.setobj(L, val, L.top);
//        LuaGC.luaC_barrier(L, LuaObject.clvalue(fi), L.top);
//        }
//        LuaLimits.lua_unlock(L);
//        return name;
        return nil
    }
}

