//package kurumi;

//
// ** $Id: lopcodes.c,v 1.37.1.1 2007/12/27 13:02:25 roberto Exp $
// ** See Copyright Notice in lua.h
//

//using lu_byte = System.Byte;
//using Instruction = System.UInt32;

public class LuaOpCodes {
    //        ===========================================================================
    //          We assume that instructions are unsigned numbers.
    //          All instructions have an opcode in the first 6 bits.
    //          Instructions can have the following fields:
    //            `A' : 8 bits
    //            `B' : 9 bits
    //            `C' : 9 bits
    //            `Bx' : 18 bits (`B' and `C' together)
    //            `sBx' : signed Bx
    //
    //          A signed argument is represented in excess K; that is, the number
    //          value is the unsigned value minus K. K is exactly the maximum value
    //          for that argument (so that -max is represented by 0, and +max is
    //          represented by 2*max), which is half the maximum for the corresponding
    //          unsigned argument.
    //        ===========================================================================

}

public enum OpMode: Int {
    /* basic instruction format */
    case iABC
    case iABx
    case iAsBx
    
    public func getValue() -> Int {
        return self.rawValue
    }
    
    public static func forValue(value:Int) -> OpMode {
        return OpMode(rawValue: value)!
    }
}

extension LuaOpCodes {
    //
    //         ** size and position of opcode arguments.
    //
    public static let SIZE_C:Int = 9
    public static let SIZE_B:Int = 9
    public static let SIZE_Bx:Int = (SIZE_C + SIZE_B)
    public static let SIZE_A:Int = 8

    public static let SIZE_OP:Int = 6

    public static let POS_OP:Int = 0
    public static let POS_A:Int = (POS_OP + SIZE_OP)
    public static let POS_C:Int = (POS_A + SIZE_A)
    public static let POS_B:Int = (POS_C + SIZE_C)
    public static let POS_Bx:Int = POS_C
    
    //
    //         ** limits for opcode arguments.
    //         ** we use (signed) int to manipulate most arguments,
    //         ** so they must fit in LUAI_BITSINT-1 bits (-1 for sign)
    //
    ///#if SIZE_Bx < LUAI_BITSINT-1
    public static let MAXARG_Bx:Int = ((1<<SIZE_Bx)-1)
    public static let MAXARG_sBx:Int = (MAXARG_Bx>>1) // `sBx' is signed
    ///#else
    //public const int MAXARG_Bx            = System.Int32.MaxValue;
    //public const int MAXARG_sBx            = System.Int32.MaxValue;
    ///#endif
    
    //public const uint MAXARG_A = (uint)((1 << (int)SIZE_A) -1);
    //public const uint MAXARG_B = (uint)((1 << (int)SIZE_B) -1);
    //public const uint MAXARG_C = (uint)((1 << (int)SIZE_C) -1);
    public static let MAXARG_A:Int64 = Int64((Int64(1 << Int(SIZE_A)) - 1) & 0xffffffff) //FIXME:
    public static let MAXARG_B:Int64 = Int64((Int64(1 << Int(SIZE_B)) - 1) & 0xffffffff) //FIXME:
    public static let MAXARG_C:Int64 = Int64((Int64(1 << Int(SIZE_C)) - 1) & 0xffffffff) //FIXME:
    
    // creates a mask with `n' 1 bits at position `p'
    //public static int MASK1(int n, int p) { return ((~((~(Instruction)0) << n)) << p); }
    public static func MASK1(n:Int, p:Int) -> Int64 { //uint
//        //return (uint)((~((~0) << n)) << p);
//        return (long)(((~((~0) << n)) << p) & 0xffffffff);
        return 0
    }
    
    // creates a mask with `n' 0 bits at position `p'
    public static func MASK0(n:Int, p:Int) -> Int64 { //uint
//        //return (uint)(~MASK1(n, p));
//        return (long)((~MASK1(n, p)) & 0xffffffff);
        return 0
    }
    
    //
    //         ** the following macros help to manipulate instructions
    //
    public static func GET_OPCODE(i:Int64) -> OpCode { //Instruction - UInt32
//        return (OpCode)longToOpCode((i >> POS_OP) & MASK1(SIZE_OP, 0));
        return OpCode.OP_MOVE
    }
    
    public static func GET_OPCODE(i:InstructionPtr) -> OpCode {
//        return GET_OPCODE(i.get(0));
        return OpCode.OP_MOVE
    }
    
    public static func SET_OPCODE(i:[Int64]!, o:Int64) { //Instruction - UInt32 - Instruction - UInt32 - ref
//        i[0] = (long)(i[0] & MASK0(SIZE_OP, POS_OP)) | ((o << POS_OP) & MASK1(SIZE_OP, POS_OP)); //Instruction - UInt32
    }
    
    public static func SET_OPCODE(i:[Int64]!, opcode:OpCode) { //Instruction - UInt32 - ref
//        i[0] = (long)(i[0] & MASK0(SIZE_OP, POS_OP)) | (((long)opcode.getValue() << POS_OP) & MASK1(SIZE_OP, POS_OP)); //uint - Instruction - UInt32
    }
    
    public static func SET_OPCODE(i:InstructionPtr!, opcode:OpCode) {
//        long[] c_ref = new long[1];
//        c_ref[0] = i.codes[i.pc];
//        SET_OPCODE(c_ref, opcode); //ref
//        i.codes[i.pc] = c_ref[0];
    }
    
    public static func GETARG_A(i:Int64) -> Int { //Instruction - UInt32
//        return (int)((i >> POS_A) & MASK1(SIZE_A, 0));
        return 0
    }
    
    public static func GETARG_A(i:InstructionPtr!) -> Int {
//        return GETARG_A(i.get(0));
        return 0
    }
    
    public static func SETARG_A(i:InstructionPtr!, u:Int) {
//        i.set(0, (long)((i.get(0) & MASK0(SIZE_A, POS_A)) | ((u << POS_A) & MASK1(SIZE_A, POS_A)))); //Instruction - UInt32
    }
    
    public static func GETARG_B(i:Int64) -> Int { //Instruction - UInt32
//        return (int)((i >> POS_B) & MASK1(SIZE_B, 0));
        return 0
    }
    
    public static func GETARG_B(i:InstructionPtr!) -> Int {
//        return GETARG_B(i.get(0));
        return 0
    }
    
    public static func SETARG_B(i:InstructionPtr!, b:Int) {
//        i.set(0, (long)((i.get(0) & MASK0(SIZE_B, POS_B)) | ((b << POS_B) & MASK1(SIZE_B, POS_B)))); //Instruction - UInt32
    }
    
    public static func GETARG_C(i:Int64) -> Int { //Instruction - UInt32
//        return (int)((i>>POS_C) & MASK1(SIZE_C, 0));
        return 0
    }
    
    public static func GETARG_C(i:InstructionPtr!) -> Int {
//        return GETARG_C(i.get(0));
        return 0
    }
    
    public static func SETARG_C(i:InstructionPtr!, b:Int) {
//        i.set(0, (long)((i.get(0) & MASK0(SIZE_C, POS_C)) | ((b << POS_C) & MASK1(SIZE_C, POS_C)))); //Instruction - UInt32
    }
    
    public static func GETARG_Bx(i:Int64) -> Int { //Instruction - UInt32
//        return (int)((i>>POS_Bx) & MASK1(SIZE_Bx, 0));
        return 0
    }
    
    public static func GETARG_Bx(i:InstructionPtr!) -> Int {
//        return GETARG_Bx(i.get(0));
        return 0
    }
    
    public static func SETARG_Bx(i:InstructionPtr!, b:Int) {
//        i.set(0, (long)((i.get(0) & MASK0(SIZE_Bx, POS_Bx)) | ((b << POS_Bx) & MASK1(SIZE_Bx, POS_Bx)))); //Instruction - UInt32
    }
    
    public static func GETARG_sBx(i:Int64) -> Int { //Instruction - UInt32
//        return (GETARG_Bx(i) - MAXARG_sBx);
        return 0
    }
    
    public static func GETARG_sBx(i:InstructionPtr!) -> Int {
//        return GETARG_sBx(i.get(0));
        return 0
    }
    
    public static func SETARG_sBx(i:InstructionPtr!, b:Int) {
//        SETARG_Bx(i, b + MAXARG_sBx);
    }
    
    //FIXME:long
    public static func CREATE_ABC(o:OpCode, a:Int, b:Int, c:Int) -> Int {
//        return (int)((o.getValue() << POS_OP) | (a << POS_A) | (b << POS_B) | (c << POS_C));
        return 0
    }
    
    //FIXME:long
    public static func CREATE_ABx(o:OpCode, a:Int, bc:Int) -> Int {
//        int result = (int)((o.getValue() << POS_OP) | (a << POS_A) | (bc << POS_Bx));
//        return (int)((o.getValue() << POS_OP) | (a << POS_A) | (bc << POS_Bx));
        return 0
    }
    
    //
    //         ** Macros to operate RK indices
    //
    
    // this bit 1 means constant (0 means register)
    public static let BITRK:Int = (1 << (SIZE_B - 1))
    
    // test whether value is a constant
    public static func ISK(x:Int) -> Int {
//        return x & BITRK;
        return 0
    }
    
    // gets the index of the constant
    public static func INDEXK(r:Int) -> Int {
//        return r & (~BITRK);
        return 0
    }
    
    public static let MAXINDEXRK:Int = BITRK - 1
    
    // code a constant index as a RK value
    public static func RKASK(x:Int) -> Int {
//        return x | BITRK;
        return 0
    }
    
    //
    //         ** invalid register that fits in 8 bits
    //
    public static let NO_REG:Int = Int(MAXARG_A)
    
    //
    //         ** R(x) - register
    //         ** Kst(x) - constant (in constant table)
    //         ** RK(x) == if ISK(x) then Kst(INDEXK(x)) else R(x)
    //
    
}


public enum OpCode : Int {
    /*----------------------------------------------------------------------
     name        args    description
     ------------------------------------------------------------------------*/
    case OP_MOVE = 0/*    A B    R(A) := R(B)                    */
    case OP_LOADK = 1/*    A Bx    R(A) := Kst(Bx)                    */
    case OP_LOADBOOL = 2/*    A B C    R(A) := (Bool)B; if (C) pc++            */
    case OP_LOADNIL = 3/*    A B    R(A) := ... := R(B) := nil            */
    case OP_GETUPVAL = 4/*    A B    R(A) := UpValue[B]                */
    
    case OP_GETGLOBAL = 5/*    A Bx    R(A) := Gbl[Kst(Bx)]                */
    case OP_GETTABLE = 6/*    A B C    R(A) := R(B)[RK(C)]                */
    
    case OP_SETGLOBAL = 7/*    A Bx    Gbl[Kst(Bx)] := R(A)                */
    case OP_SETUPVAL = 8/*    A B    UpValue[B] := R(A)                */
    case OP_SETTABLE = 9/*    A B C    R(A)[RK(B)] := RK(C)                */
    
    case OP_NEWTABLE = 10/*    A B C    R(A) := {} (size = B,C)                */
    
    case OP_SELF = 11/*    A B C    R(A+1) := R(B); R(A) := R(B)[RK(C)]        */
    
    case OP_ADD = 12/*    A B C    R(A) := RK(B) + RK(C)                */
    case OP_SUB = 13/*    A B C    R(A) := RK(B) - RK(C)                */
    case OP_MUL = 14/*    A B C    R(A) := RK(B) * RK(C)                */
    case OP_DIV = 15/*    A B C    R(A) := RK(B) / RK(C)                */
    case OP_MOD = 16/*    A B C    R(A) := RK(B) % RK(C)                */
    case OP_POW = 17/*    A B C    R(A) := RK(B) ^ RK(C)                */
    case OP_UNM = 18/*    A B    R(A) := -R(B)                    */
    case OP_NOT = 19/*    A B    R(A) := not R(B)                */
    case OP_LEN = 20/*    A B    R(A) := length of R(B)                */
    
    case OP_CONCAT = 21/*    A B C    R(A) := R(B).. ... ..R(C)            */
    
    case OP_JMP = 22/*    sBx    pc+=sBx                    */
    
    case OP_EQ = 23/*    A B C    if ((RK(B) == RK(C)) ~= A) then pc++        */
    case OP_LT = 24/*    A B C    if ((RK(B) <  RK(C)) ~= A) then pc++          */
    case OP_LE = 25/*    A B C    if ((RK(B) <= RK(C)) ~= A) then pc++          */
    
    case OP_TEST = 26/*    A C    if not (R(A) <=> C) then pc++            */
    case OP_TESTSET = 27/*    A B C    if (R(B) <=> C) then R(A) := R(B) else pc++    */
    
    case OP_CALL = 28 /*    A B C    R(A), ... ,R(A+C-2) := R(A)(R(A+1), ... ,R(A+B-1)) */
    case OP_TAILCALL = 29/*    A B C    return R(A)(R(A+1), ... ,R(A+B-1))        */
    case OP_RETURN = 30/*    A B    return R(A), ... ,R(A+B-2)    (see note)    */
    
    case OP_FORLOOP = 31/*    A sBx    R(A)+=R(A+2);
     if R(A) <?= R(A+1) then { pc+=sBx; R(A+3)=R(A) }*/
    case OP_FORPREP = 32/*    A sBx    R(A)-=R(A+2); pc+=sBx                */
    
    case OP_TFORLOOP = 33/*    A C    R(A+3), ... ,R(A+2+C) := R(A)(R(A+1), R(A+2));
     if R(A+3) ~= nil then R(A+2)=R(A+3) else pc++    */
    case OP_SETLIST = 34/*    A B C    R(A)[(C-1)*FPF+i] := R(A+i), 1 <= i <= B    */
    
    case OP_CLOSE = 35/*    A     close all variables in the stack up to (>=) R(A)*/
    case OP_CLOSURE = 36/*    A Bx    R(A) := closure(KPROTO[Bx], R(A), ... ,R(A+n))    */
    
    case OP_VARARG = 37/*    A B    R(A), R(A+1), ..., R(A+B-1) = vararg        */
    
    public func getValue() -> Int {
        return self.rawValue
    }
    
    public static func forValue(value:Int) -> OpCode {
        return OpCode(rawValue: value)!
    }
}

extension LuaOpCodes {
    public static func opCodeToLong(code:OpCode) -> Int64 {
        switch (code) {
        case .OP_MOVE:
            return 0
        
        case .OP_LOADK:
            return 1;
            
        case .OP_LOADBOOL:
            return 2;
        
        case .OP_LOADNIL:
            return 3
            
        case .OP_GETUPVAL:
            return 4
            
        case .OP_GETGLOBAL:
            return 5
            
        case .OP_GETTABLE:
            return 6
            
        case .OP_SETGLOBAL:
            return 7
            
        case .OP_SETUPVAL:
            return 8
            
        case .OP_SETTABLE:
            return 9
            
        case .OP_NEWTABLE:
            return 10
            
        case .OP_SELF:
            return 11
            
        case .OP_ADD:
            return 12
            
        case .OP_SUB:
            return 13
            
        case .OP_MUL:
            return 14
            
        case .OP_DIV:
            return 15
            
        case .OP_MOD:
            return 16
            
        case .OP_POW:
            return 17
            
        case .OP_UNM:
            return 18
            
        case .OP_NOT:
            return 19
            
        case .OP_LEN:
            return 20
            
        case .OP_CONCAT:
            return 21
            
        case .OP_JMP:
            return 22
            
        case .OP_EQ:
            return 23
            
        case .OP_LT:
            return 24
            
        case .OP_LE:
            return 25
            
        case .OP_TEST:
            return 26
            
        case .OP_TESTSET:
            return 27
            
        case .OP_CALL:
            return 28
            
        case .OP_TAILCALL:
            return 29
            
        case .OP_RETURN:
            return 30
            
        case .OP_FORLOOP:
            return 31
            
        case .OP_FORPREP:
            return 32
            
        case .OP_TFORLOOP:
            return 33
            
        case .OP_SETLIST:
            return 34
            
        case .OP_CLOSE:
            return 35
            
        case .OP_CLOSURE:
            return 36
            
        case .OP_VARARG:
            return 37
        }
        //throw new RuntimeException("OpCode error");
    }
    
    
    public static func longToOpCode(code:Int64) -> OpCode {
        switch (Int(code)) {
        case 0:
            return OpCode.OP_MOVE
        
        case 1:
            return OpCode.OP_LOADK
        
        case 2:
            return OpCode.OP_LOADBOOL
        
        case 3:
            return OpCode.OP_LOADNIL
        
        case 4:
            return OpCode.OP_GETUPVAL
        
        case 5:
            return OpCode.OP_GETGLOBAL
        
        case 6:
            return OpCode.OP_GETTABLE
        
        case 7:
            return OpCode.OP_SETGLOBAL
        
        case 8:
            return OpCode.OP_SETUPVAL
        
        case 9:
            return OpCode.OP_SETTABLE
        
        case 10:
            return OpCode.OP_NEWTABLE
        
        case 11:
            return OpCode.OP_SELF
        
        case 12:
            return OpCode.OP_ADD
        
        case 13:
            return OpCode.OP_SUB
        
        case 14:
            return OpCode.OP_MUL
        
        case 15:
            return OpCode.OP_DIV
        
        case 16:
            return OpCode.OP_MOD
        
        case 17:
            return OpCode.OP_POW
        
        case 18:
            return OpCode.OP_UNM
        
        case 19:
            return OpCode.OP_NOT
        
        case 20:
            return OpCode.OP_LEN
        
        case 21:
            return OpCode.OP_CONCAT
        
        case 22:
            return OpCode.OP_JMP
        
        case 23:
            return OpCode.OP_EQ
        
        case 24:
            return OpCode.OP_LT
        
        case 25:
            return OpCode.OP_LE
        
        case 26:
            return OpCode.OP_TEST
        
        case 27:
            return OpCode.OP_TESTSET
        
        case 28:
            return OpCode.OP_CALL
        
        case 29:
            return OpCode.OP_TAILCALL
        
        case 30:
            return OpCode.OP_RETURN
        
        case 31:
            return OpCode.OP_FORLOOP
        
        case 32:
            return OpCode.OP_FORPREP
        
        case 33:
            return OpCode.OP_TFORLOOP
        
        case 34:
            return OpCode.OP_SETLIST
        
        case 35:
            return OpCode.OP_CLOSE
        
        case 36:
            return OpCode.OP_CLOSURE
        
        case 37:
            return OpCode.OP_VARARG
            
        default:
            assert(false, "OpCode error")
        }
        //throw new RuntimeException("OpCode error");
    }
}

/*===========================================================================
 Notes:
 (*) In OP_CALL, if (B == 0) then B = top. C is the number of returns - 1,
 and can be 0: OP_CALL then sets `top' to last_result+1, so
 next open instruction (OP_CALL, OP_RETURN, OP_SETLIST) may use `top'.
 
 (*) In OP_VARARG, if (B == 0) then use actual number of varargs and
 set top (like in OP_CALL with C == 0).
 
 (*) In OP_RETURN, if (B == 0) then return up to `top'
 
 (*) In OP_SETLIST, if (B == 0) then B = `top';
 if (C == 0) then next `instruction' is real C
 
 (*) For comparisons, A specifies what condition the test should accept
 (true or false).
 
 (*) All `skips' (pc++) assume that next instruction is a jump
 ===========================================================================*/


/*
 ** masks for instruction properties. The format is:
 ** bits 0-1: op mode
 ** bits 2-3: C arg mode
 ** bits 4-5: B arg mode
 ** bit 6: instruction set register A
 ** bit 7: operator is a test
 */
public enum OpArgMask : Int {
    case OpArgN  /* argument is not used */
    case OpArgU  /* argument is used */
    case OpArgR  /* argument is a register or a jump offset */
    case OpArgK   /* argument is a constant or register/constant */
    
    public func getValue() -> Int {
        return self.rawValue
    }
    
    public static func forValue(value:Int) -> OpArgMask {
        return OpArgMask(rawValue: value)!
    }
}

extension LuaOpCodes {
    //
    //         ** grep "ORDER OP" if you change these enums
    //
    public static func getOpMode(m:OpCode) -> OpMode {
        switch (luaP_opmodes[m.getValue()] & 3) {
        case 0:
            return OpMode.iABC
            
        case 1:
            return OpMode.iABx
            
        case 2:
            return OpMode.iAsBx
        
        default:
            return OpMode.iABC
        }
    }
    
    public static func getBMode(m:OpCode) -> OpArgMask {
//        switch ((luaP_opmodes[m.getValue()] >> 4) & 3) {
//        default:
//        case 0:
//        return OpArgMask.OpArgN;
//        case 1:
//        return OpArgMask.OpArgU;
//        case 2:
//        return OpArgMask.OpArgR;
//        case 3:
//        return OpArgMask.OpArgK;
//        }
        return OpArgMask.OpArgK
    }
    
    public static func getCMode(m:OpCode) -> OpArgMask {
//        switch ((luaP_opmodes[m.getValue()] >> 2) & 3) {
//        default:
//        case 0:
//        return OpArgMask.OpArgN;
//        case 1:
//        return OpArgMask.OpArgU;
//        case 2:
//        return OpArgMask.OpArgR;
//        case 3:
//        return OpArgMask.OpArgK;
//        }
        return OpArgMask.OpArgK
    }
    
    public static func testAMode(m:OpCode) -> Int {
//        return luaP_opmodes[m.getValue()] & (1 << 6);
        return 0
    }
    
    public static func testTMode(m:OpCode) -> Int {
//        return luaP_opmodes[m.getValue()] & (1 << 7);
        return 0
    }
    
    // number of list items to accumulate before a SETLIST instruction
    public static let LFIELDS_PER_FLUSH:Int = 50
    
    // ORDER OP
    public static let luaP_opnames:[CharPtr] = [
//        CLib.CharPtr.toCharPtr("MOVE"),
//        CLib.CharPtr.toCharPtr("LOADK"),
//        CLib.CharPtr.toCharPtr("LOADBOOL"),
//        CLib.CharPtr.toCharPtr("LOADNIL"),
//        CLib.CharPtr.toCharPtr("GETUPVAL"),
//        CLib.CharPtr.toCharPtr("GETGLOBAL"),
//        CLib.CharPtr.toCharPtr("GETTABLE"),
//        CLib.CharPtr.toCharPtr("SETGLOBAL"),
//        CLib.CharPtr.toCharPtr("SETUPVAL"),
//        CLib.CharPtr.toCharPtr("SETTABLE"),
//        CLib.CharPtr.toCharPtr("NEWTABLE"),
//        CLib.CharPtr.toCharPtr("SELF"),
//        CLib.CharPtr.toCharPtr("ADD"),
//        CLib.CharPtr.toCharPtr("SUB"),
//        CLib.CharPtr.toCharPtr("MUL"),
//        CLib.CharPtr.toCharPtr("DIV"),
//        CLib.CharPtr.toCharPtr("MOD"),
//        CLib.CharPtr.toCharPtr("POW"),
//        CLib.CharPtr.toCharPtr("UNM"),
//        CLib.CharPtr.toCharPtr("NOT"),
//        CLib.CharPtr.toCharPtr("LEN"),
//        CLib.CharPtr.toCharPtr("CONCAT"),
//        CLib.CharPtr.toCharPtr("JMP"),
//        CLib.CharPtr.toCharPtr("EQ"),
//        CLib.CharPtr.toCharPtr("LT"),
//        CLib.CharPtr.toCharPtr("LE"),
//        CLib.CharPtr.toCharPtr("TEST"),
//        CLib.CharPtr.toCharPtr("TESTSET"),
//        CLib.CharPtr.toCharPtr("CALL"),
//        CLib.CharPtr.toCharPtr("TAILCALL"),
//        CLib.CharPtr.toCharPtr("RETURN"),
//        CLib.CharPtr.toCharPtr("FORLOOP"),
//        CLib.CharPtr.toCharPtr("FORPREP"),
//        CLib.CharPtr.toCharPtr("TFORLOOP"),
//        CLib.CharPtr.toCharPtr("SETLIST"),
//        CLib.CharPtr.toCharPtr("CLOSE"),
//        CLib.CharPtr.toCharPtr("CLOSURE"),
//        CLib.CharPtr.toCharPtr("VARARG")
    ]
    
    private static func opmode(t:Int8, a:Int8, b:OpArgMask, c:OpArgMask, m:OpMode) -> Int8 { //lu_byte - lu_byte - lu_byte
//        int bValue = 0;
//        int cValue = 0;
//        int mValue = 0;
//        switch (b) {
//        case OpArgN:
//        bValue = 0;
//        break;
//        case OpArgU:
//        bValue = 1;
//        break;
//        case OpArgR:
//        bValue = 2;
//        break;
//        case OpArgK:
//        bValue = 3;
//        break;
//        }
//        switch (c) {
//        case OpArgN:
//        cValue = 0;
//        break;
//        case OpArgU:
//        cValue = 1;
//        break;
//        case OpArgR:
//        cValue = 2;
//        break;
//        case OpArgK:
//        cValue = 3;
//        break;
//        }
//        switch (m) {
//        case iABC:
//        mValue = 0;
//        break;
//        case iABx:
//        mValue = 1;
//        break;
//        case iAsBx:
//        mValue = 2;
//        break;
//        }
//        return (byte)(((t) << 7) | ((a) << 6) | (((byte)bValue) << 4) | (((byte)cValue) << 2) | ((byte)mValue)); //lu_byte - lu_byte - lu_byte - lu_byte
        return 0
    }

    //       T  A    B       C     mode           opcode
    //lu_byte[]
    private static let luaP_opmodes:[Int8] = [
//        opmode((byte)0, (byte)1, OpArgMask.OpArgR, OpArgMask.OpArgN, OpMode.iABC),
//        opmode((byte)0, (byte)1, OpArgMask.OpArgK, OpArgMask.OpArgN, OpMode.iABx),
//        opmode((byte)0, (byte)1, OpArgMask.OpArgU, OpArgMask.OpArgU, OpMode.iABC),
//        opmode((byte)0, (byte)1, OpArgMask.OpArgR, OpArgMask.OpArgN, OpMode.iABC),
//        opmode((byte)0, (byte)1, OpArgMask.OpArgU, OpArgMask.OpArgN, OpMode.iABC),
//        opmode((byte)0, (byte)1, OpArgMask.OpArgK, OpArgMask.OpArgN, OpMode.iABx),
//        opmode((byte)0, (byte)1, OpArgMask.OpArgR, OpArgMask.OpArgK, OpMode.iABC),
//        opmode((byte)0, (byte)0, OpArgMask.OpArgK, OpArgMask.OpArgN, OpMode.iABx),
//        opmode((byte)0, (byte)0, OpArgMask.OpArgU, OpArgMask.OpArgN, OpMode.iABC),
//        opmode((byte)0, (byte)0, OpArgMask.OpArgK, OpArgMask.OpArgK, OpMode.iABC),
//        opmode((byte)0, (byte)1, OpArgMask.OpArgU, OpArgMask.OpArgU, OpMode.iABC),
//        opmode((byte)0, (byte)1, OpArgMask.OpArgR, OpArgMask.OpArgK, OpMode.iABC),
//        opmode((byte)0, (byte)1, OpArgMask.OpArgK, OpArgMask.OpArgK, OpMode.iABC),
//        opmode((byte)0, (byte)1, OpArgMask.OpArgK, OpArgMask.OpArgK, OpMode.iABC),
//        opmode((byte)0, (byte)1, OpArgMask.OpArgK, OpArgMask.OpArgK, OpMode.iABC),
//        opmode((byte)0, (byte)1, OpArgMask.OpArgK, OpArgMask.OpArgK, OpMode.iABC),
//        opmode((byte)0, (byte)1, OpArgMask.OpArgK, OpArgMask.OpArgK, OpMode.iABC),
//        opmode((byte)0, (byte)1, OpArgMask.OpArgK, OpArgMask.OpArgK, OpMode.iABC),
//        opmode((byte)0, (byte)1, OpArgMask.OpArgR, OpArgMask.OpArgN, OpMode.iABC),
//        opmode((byte)0, (byte)1, OpArgMask.OpArgR, OpArgMask.OpArgN, OpMode.iABC),
//        opmode((byte)0, (byte)1, OpArgMask.OpArgR, OpArgMask.OpArgN, OpMode.iABC),
//        opmode((byte)0, (byte)1, OpArgMask.OpArgR, OpArgMask.OpArgR, OpMode.iABC),
//        opmode((byte)0, (byte)0, OpArgMask.OpArgR, OpArgMask.OpArgN, OpMode.iAsBx),
//        opmode((byte)1, (byte)0, OpArgMask.OpArgK, OpArgMask.OpArgK, OpMode.iABC),
//        opmode((byte)1, (byte)0, OpArgMask.OpArgK, OpArgMask.OpArgK, OpMode.iABC),
//        opmode((byte)1, (byte)0, OpArgMask.OpArgK, OpArgMask.OpArgK, OpMode.iABC),
//        opmode((byte)1, (byte)1, OpArgMask.OpArgR, OpArgMask.OpArgU, OpMode.iABC),
//        opmode((byte)1, (byte)1, OpArgMask.OpArgR, OpArgMask.OpArgU, OpMode.iABC),
//        opmode((byte)0, (byte)1, OpArgMask.OpArgU, OpArgMask.OpArgU, OpMode.iABC),
//        opmode((byte)0, (byte)1, OpArgMask.OpArgU, OpArgMask.OpArgU, OpMode.iABC),
//        opmode((byte)0, (byte)0, OpArgMask.OpArgU, OpArgMask.OpArgN, OpMode.iABC),
//        opmode((byte)0, (byte)1, OpArgMask.OpArgR, OpArgMask.OpArgN, OpMode.iAsBx),
//        opmode((byte)0, (byte)1, OpArgMask.OpArgR, OpArgMask.OpArgN, OpMode.iAsBx),
//        opmode((byte)1, (byte)0, OpArgMask.OpArgN, OpArgMask.OpArgU, OpMode.iABC),
//        opmode((byte)0, (byte)0, OpArgMask.OpArgU, OpArgMask.OpArgU, OpMode.iABC),
//        opmode((byte)0, (byte)0, OpArgMask.OpArgN, OpArgMask.OpArgN, OpMode.iABC),
//        opmode((byte)0, (byte)1, OpArgMask.OpArgU, OpArgMask.OpArgN, OpMode.iABx),
//        opmode((byte)0, (byte)1, OpArgMask.OpArgU, OpArgMask.OpArgN, OpMode.iABC)
    ]
    
    public static let NUM_OPCODES:Int = OpCode.OP_VARARG.rawValue
}
