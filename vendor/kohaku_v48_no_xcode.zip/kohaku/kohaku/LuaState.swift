//package kurumi;

//
// ** $Id: lstate.c,v 2.36.1.2 2008/01/03 15:20:39 roberto Exp $
// ** Global State
// ** See Copyright Notice in lua.h
//

//using lu_byte = System.Byte;
//using lu_int32 = System.Int32;
//using lu_mem = System.UInt32;
//using TValue = Lua.TValue;
//using StkId = TValue;
//using ptrdiff_t = System.Int32;
//using Instruction = System.UInt32;

public class LuaState {
    // table of globals
    public static func gt(L:lua_State!) -> TValue! {
//        return L.l_gt;
        return nil
    }
    
    // registry
    public static func registry(L:lua_State!) -> TValue! {
//        return G(L).l_registry;
        return nil
    }
    
    // extra stack space to handle TM calls and some other extras
    public static let EXTRA_STACK:Int = 5
    
    public static let BASIC_CI_SIZE:Int = 8
    
    public static let BASIC_STACK_SIZE:Int = (2*Lua.LUA_MINSTACK)
}

public class stringtable {
    public var hash:[GCObject?]!
    public var/*UInt32*//*lu_mem*/ nuse:Int64 = 0  /* number of elements */
    public var size:Int = 0
}


/*
 ** informations about a call
 */
public class CallInfo: ArrayElement {
    private var values:[CallInfo]! = nil
    private var index:Int = -1
    
    public var base_:TValue!  /*StkId*/ /* base for this function */
    public var func_:TValue!  /*StkId*/ /* function index in the stack */
    public var top:TValue!  /*StkId*/ /* top for this function */
    public var savedpc:InstructionPtr!
    public var nresults:Int = 0  /* expected number of results from this function */
    public var tailcalls:Int = 0  /* number of tail calls lost under this entry */
    
    public func set_index(index:Int) {
        self.index = index;
    }
    
    public func set_array(array:Any!) {
//        this.values = (CallInfo[])array;
//        ClassType.Assert(this.values != null);
    }
    
    public func get(offset:Int) -> CallInfo! {
//        return values[index + offset];
        return nil
    }
    
    public static func plus(value:CallInfo!, offset:Int) -> CallInfo! {
//        return value.values[value.index + offset];
        return nil
    }
    
    public static func minus(value:CallInfo!, offset:Int) -> CallInfo! {
//        return value.values[value.index - offset];
        return nil
    }
    
    public static func minus(ci:CallInfo!, values:[CallInfo]!) -> Int {
//    ClassType.Assert(ci.values == values);
//    return ci.index;
        return 0
    }
    
    public static func minus(ci1:CallInfo!, ci2:CallInfo!) -> Int {
//        ClassType.Assert(ci1.values == ci2.values);
//        return ci1.index - ci2.index;
        return 0
    }
    
    public static func lessThan(ci1:CallInfo!, ci2:CallInfo!) -> Bool {
//        ClassType.Assert(ci1.values == ci2.values);
//        return ci1.index < ci2.index;
        return false
    }
    
    public static func lessEqual(ci1:CallInfo!, ci2:CallInfo!) -> Bool {
//    ClassType.Assert(ci1.values == ci2.values);
//    return ci1.index <= ci2.index;
        return false
    }
    
    public static func greaterThan(ci1:CallInfo!, ci2:CallInfo!) -> Bool {
//        ClassType.Assert(ci1.values == ci2.values);
//        return ci1.index > ci2.index;
        return false
    }
    
    public static func greaterEqual(ci1:CallInfo!, ci2:CallInfo!) -> Bool {
//    ClassType.Assert(ci1.values == ci2.values);
//    return ci1.index >= ci2.index;
        return false
    }
    
    public static func inc(/*ref*/ value:[CallInfo]!) -> CallInfo! {
//        value[0] = value[0].get(1);
//        return value[0].get(-1);
        return nil
    }
    
    public static func dec(/*ref*/ value:[CallInfo]!) -> CallInfo! {
//        value[0] = value[0].get(-1);
//        return value[0].get(1);
        return nil
    }
}

extension LuaState {
    public static func curr_func(L:lua_State!) -> Closure! {
//        return (LuaObject.clvalue(L.ci.func));
        return nil
    }
    
    public static func ci_func(ci:CallInfo!) -> Closure! {
//        return (LuaObject.clvalue(ci.func));
        return nil
    }
    
    public static func f_isLua(ci:CallInfo!) -> Bool {
//        return ci_func(ci).c.getIsC() == 0;
        return false
    }
    
    public static func isLua(ci:CallInfo!) -> Bool {
//        return (LuaObject.ttisfunction((ci).func) && f_isLua(ci));
        return false
    }
}

/*
 ** `global state', shared by all threads of this state
 */
public class global_State {
    public var strt:stringtable! = stringtable() /* hash table for strings */
    public var frealloc:lua_Alloc!  /* function to reallocate memory */
    public var ud:Any!         /* auxiliary data to `frealloc' */
    public var currentwhite:Int8 = 0  /*Byte*/ /*lu_byte*/
    public var gcstate:Int8 = 0 /*Byte*/ /*lu_byte*/  /* state of garbage collector */
    public var sweepstrgc:Int = 0  /* position of sweep in `strt' */
    public var rootgc:GCObject!  /* list of all collectable objects */
    public var sweepgc:GCObjectRef!  /* position of sweep in `rootgc' */
    public var gray:GCObject!  /* list of gray objects */
    public var grayagain:GCObject!  /* list of objects to be traversed atomically */
    public var weak:GCObject!  /* list of weak tables (to be cleared) */
    public var tmudata:GCObject!  /* last element of list of userdata to be GC */
    public var buff:Mbuffer! = Mbuffer()  /* temporary buffer for string concatentation */
    public var/*UInt32*//*lu_mem*/ GCthreshold:Int64 = 0
    public var/*UInt32*//*lu_mem*/ totalbytes:Int64 = 0  /* number of bytes currently allocated */
    public var/*UInt32*//*lu_mem*/ estimate:Int64 = 0  /* an estimate of number of bytes actually in use */
    public var/*UInt32*//*lu_mem*/ gcdept:Int64 = 0  /* how much GC is `behind schedule' */
    public var gcpause:Int = 0  /* size of pause between successive GCs */
    public var gcstepmul:Int = 0  /* GC `granularity' */
    public var panic:lua_CFunction!  /* to be called in unprotected errors */
    public var l_registry:TValue! = TValue()
    public var mainthread:lua_State!
    public var uvhead:UpVal! = UpVal()  /* head of double-linked list of all open upvalues */
    public var mt:[Table?]! = [Table?](repeating: nil, count: LuaObject.NUM_TAGS)  /* metatables for basic types */
    public var tmname:[TString?]! = [TString?](repeating:nil, count: TMS.TM_N.getValue()) // array with tag-method names
}
public class lua_State: GCObject {
    public var status:Int8 = 0 /*Byte*/ /*lu_byte*/
    public var/*StkId*/ top:TValue!  /* first free slot in the stack */
    public var/*StkId*/ base_:TValue!  /* base of current function */
    public var l_G:global_State!
    public var ci:CallInfo!  /* call info for current function */
    public var savedpc:InstructionPtr! = InstructionPtr()  /* `savedpc' of current function */
    public var/*StkId*/ stack_last:TValue!  /* last free slot in the stack */
    public var/*StkId[]*/ stack:[TValue]!  /* stack base */
    public var end_ci:CallInfo!  /* points after end of ci array*/
    public var base_ci:[CallInfo]!  /* array of CallInfo's */
    public var stacksize:Int = 0
    public var size_ci:Int = 0  /* size of array `base_ci' */
    public var/*ushort*/ nCcalls:Int = 0  /* number of nested C calls */
    public var/*ushort*/ baseCcalls:Int = 0  /* nested C calls when resuming coroutine */
    public var hookmask:Int8 = 0 /*Byte*/ /*lu_byte*/
    public var allowhook:Int8 = 0 /*Byte*/ /*lu_byte*/
    public var basehookcount:Int = 0
    public var hookcount:Int = 0
    public var hook:lua_Hook!
    public var l_gt:TValue! = TValue()  /* table of globals */
    public var env:TValue! = TValue()  /* temporary place for environments */
    public var openupval:GCObject!  /* list of open upvalues in this stack */
    public var gclist:GCObject!
    public var errorJmp:lua_longjmp!  /* current error recover point */
    public var/*Int32*//*ptrdiff_t*/ errfunc:Int = 0  /* current error handling function (stack index) */
}

extension LuaState {
    public static func G(L:lua_State!) -> global_State! {
//        return L.l_G;
        return nil
    }
    
    public static func G_set(L:lua_State!, s:global_State!) {
//        L.l_G = s;
    }
}

public class GCObject : GCheader, ArrayElement {
    // todo: remove this?
    //private GCObject[] values = null;
    //private int index = -1;
    
    public func set_index(index:Int) {
        //this.index = index;
    }
    
    public func set_array(array:Any!) {
        //this.values = (GCObject[])array;
        //ClassType.Assert(this.values != null);
    }
    
    public func getGch() -> GCheader! {
//        return (LuaObject.GCheader)this;
        return nil
    }
    
    public func getTs() -> TString! {
//        return (LuaObject.TString)this;
        return nil
    }
    
    public func getU() -> Udata! {
//        return (LuaObject.Udata)this;
        return nil
    }
    
    public func getCl() -> Closure! {
//        return (LuaObject.Closure)this;
        return nil
    }
    
    public func getH() -> Table! {
//        return (LuaObject.Table)this;
        return nil
    }
    
    public func getP() -> Proto! {
//        return (LuaObject.Proto)this;
        return nil
    }
    
    public func getUv() -> UpVal! {
//        return (LuaObject.UpVal)this;
        return nil
    }
    
    public func getTh() -> lua_State! {
//        return (lua_State)this;
        return nil
    }
}

/*
 ** this interface and is used for implementing GCObject references,
 ** it's used to emulate the behaviour of a C-style GCObject
 */
public protocol GCObjectRef {
    func set(value:GCObject!)
    func get() -> GCObject!
}

public class ArrayRef : GCObjectRef, ArrayElement {
//    // ArrayRef is used to reference GCObject objects in an array, the next two members
//    // point to that array and the index of the GCObject element we are referencing
//    private GCObject[] array_elements;
//    private int array_index;
//
//    // ArrayRef is itself stored in an array and derived from ArrayElement, the next
//    // two members refer to itself i.e. the array and index of it's own instance.
//    private ArrayRef[] vals;
//    private int index;
    
    public init() {
//        this.array_elements = null;
//        this.array_index = 0;
//        this.vals = null;
//        this.index = 0;
    }
    
    public init(array_elements:[GCObject]!, array_index:Int) {
//        this.array_elements = array_elements;
//        this.array_index = array_index;
//        this.vals = null;
//        this.index = 0;
    }
    
    public func set(value:GCObject!) {
//        array_elements[array_index] = value;
    }
    
    public func get() -> GCObject! {
//        return array_elements[array_index];
        return nil
    }
    
    public func set_index(index:Int) {
//        this.index = index;
    }
    
    public func set_array(array/*vals*/:Any!) {
//    // don't actually need this
//    this.vals = (ArrayRef[])vals;
//    ClassType.Assert(this.vals != null);
    }
}

public class OpenValRef: GCObjectRef {
//    private LuaState.lua_State L;
    
    public init(L:lua_State!) {
//        this.L = L;
    }
    
    public func set(value:GCObject!) {
//        this.L.openupval = value;
    }
    
    public func get() -> GCObject! {
//        return this.L.openupval;
        return nil
    }
}

public class RootGCRef: GCObjectRef {
//    private LuaState.global_State g;
    
    public init(g:global_State!) {
//        this.g = g;
    }
    
    public func set(value:GCObject!) {
//        this.g.rootgc = value;
    }
    
    public func get() -> GCObject! {
//        return this.g.rootgc;
        return nil
    }
}

public class NextRef : GCObjectRef {
//    private LuaObject.GCheader header;
    
    public init(header:GCheader!) {
//        this.header = header;
    }
    
    public func set(value:GCObject!) {
//        this.header.next = value;
    }
    
    public func get() -> GCObject! {
//        return this.header.next;
        return nil
    }
}

extension LuaState {
    // macros to convert a GCObject into a specific value
    public static func rawgco2ts(o:GCObject!) -> TString! {
//        return (LuaObject.TString)LuaLimits.check_exp(o.getGch().tt == Lua.LUA_TSTRING, o.getTs());
        return nil
    }
    
    public static func gco2ts(o:GCObject!) -> TString! {
//        return (LuaObject.TString)(rawgco2ts(o).getTsv());
        return nil
    }
    
    public static func rawgco2u(o:GCObject!) -> Udata! {
//        return (LuaObject.Udata)LuaLimits.check_exp(o.getGch().tt == Lua.LUA_TUSERDATA, o.getU());
        return nil
    }
    
    public static func gco2u(o:GCObject!) -> Udata! {
//        return (LuaObject.Udata)(rawgco2u(o).uv);
        return nil
    }
    
    public static func gco2cl(o:GCObject!) -> Closure! {
//        return (LuaObject.Closure)LuaLimits.check_exp(o.getGch().tt == Lua.LUA_TFUNCTION, o.getCl());
        return nil
    }
    
    public static func gco2h(o:GCObject!) -> Table! {
//        return (LuaObject.Table)LuaLimits.check_exp(o.getGch().tt == Lua.LUA_TTABLE, o.getH());
        return nil
    }
    
    public static func gco2p(o:GCObject!) -> Proto! {
//        return (LuaObject.Proto)LuaLimits.check_exp(o.getGch().tt == LuaObject.LUA_TPROTO, o.getP());
        return nil
    }
    
    public static func gco2uv(o:GCObject!) -> UpVal! {
//        return (LuaObject.UpVal)LuaLimits.check_exp(o.getGch().tt == LuaObject.LUA_TUPVAL, o.getUv());
        return nil
    }
    
    public static func ngcotouv(o:GCObject!) -> UpVal! {
//        return (LuaObject.UpVal)LuaLimits.check_exp((o == null) || (o.getGch().tt == LuaObject.LUA_TUPVAL), o.getUv());
        return nil
    }
    
    public static func gco2th(o:GCObject!) -> lua_State! {
//        return (lua_State)LuaLimits.check_exp(o.getGch().tt == Lua.LUA_TTHREAD, o.getTh());
        return nil
    }
    
    // macro to convert any Lua object into a GCObject
    public static func obj2gco(v:Any!) -> GCObject! {
//        return (GCObject)v;
        return nil
    }
    
    public static func state_size(x:Any!, t:ClassType!) -> Int {
//        return t.GetMarshalSizeOf() + LuaConf.LUAI_EXTRASPACE; //Marshal.SizeOf(x)
        return 0
    }
    
    //
    //        public static lu_byte fromstate(object l)
    //        {
    //            return (lu_byte)(l - LUAI_EXTRASPACE);
    //        }
    //
    
    public static func tostate(l:Any!) -> lua_State! {
//        ClassType.Assert(LuaConf.LUAI_EXTRASPACE == 0, "LUAI_EXTRASPACE not supported");
//        return (lua_State)l;
        return nil
    }
}

/*
 ** Main thread combines a thread state and the global state
 */
public class LG: lua_State {
    public var g:global_State! = global_State()
    
    public func getL() -> lua_State! {
//        return this;
        return nil
    }
}

extension LuaState {
    private static func stack_init(L1:lua_State!, L:lua_State!) {
//        // initialize CallInfo array
//        L1.base_ci = LuaMem.luaM_newvector_CallInfo(L, BASIC_CI_SIZE, new ClassType(ClassType.TYPE_CALLINFO));
//        L1.ci = L1.base_ci[0];
//        L1.size_ci = BASIC_CI_SIZE;
//        L1.end_ci = L1.base_ci[L1.size_ci - 1];
//        // initialize stack array
//        L1.stack = LuaMem.luaM_newvector_TValue(L, BASIC_STACK_SIZE + EXTRA_STACK, new ClassType(ClassType.TYPE_TVALUE));
//        L1.stacksize = BASIC_STACK_SIZE + EXTRA_STACK;
//        L1.top = L1.stack[0];
//        L1.stack_last = L1.stack[L1.stacksize - EXTRA_STACK - 1];
//        // initialize first ci
//        L1.ci.func = L1.top;
//        LuaObject.TValue[] top = new LuaObject.TValue[1];
//        top[0] = L1.top;
//        LuaObject.TValue ret = LuaObject.TValue.inc(top); //ref - StkId
//        L1.top = top[0];
//        LuaObject.setnilvalue(ret); // `function' entry for this `ci'
//        L1.base_ = L1.ci.base_ = L1.top;
//        L1.ci.top = LuaObject.TValue.plus(L1.top, Lua.LUA_MINSTACK);
    }
    
    private static func freestack(L:lua_State!, L1:lua_State!) {
//        LuaMem.luaM_freearray_CallInfo(L, L1.base_ci, new ClassType(ClassType.TYPE_CALLINFO));
//        LuaMem.luaM_freearray_TValue(L, L1.stack, new ClassType(ClassType.TYPE_TVALUE));
    }
    
    //
    //         ** open parts that may cause memory-allocation errors
    //
    private static func f_luaopen(L:lua_State!, ud:Any!) {
//        global_State g = G(L);
//        //UNUSED(ud);
//        stack_init(L, L); // init stack
//        LuaObject.sethvalue(L, gt(L), LuaTable.luaH_new(L, 0, 2)); // table of globals
//        LuaObject.sethvalue(L, registry(L), LuaTable.luaH_new(L, 0, 2)); // registry
//        LuaString.luaS_resize(L, LuaLimits.MINSTRTABSIZE); // initial size of string table
//        LuaTM.luaT_init(L);
//        LuaLex.luaX_init(L);
//        LuaString.luaS_fix(LuaString.luaS_newliteral(L, CLib.CharPtr.toCharPtr(LuaMem.MEMERRMSG)));
//        g.GCthreshold = 4 * g.totalbytes;
    }
}

public class f_luaopen_delegate: Pfunc {
    public func exec(L:lua_State!, ud:Any!) {
//        f_luaopen(L, ud);
    }
}

extension LuaState {
    private static func preinit_state(L:lua_State!, g:global_State!) {
//        G_set(L, g);
//        L.stack = null;
//        L.stacksize = 0;
//        L.errorJmp = null;
//        L.hook = null;
//        L.hookmask = 0;
//        L.basehookcount = 0;
//        L.allowhook = 1;
//        LuaDebug.resethookcount(L);
//        L.openupval = null;
//        L.size_ci = 0;
//        L.nCcalls = L.baseCcalls = 0;
//        L.status = 0;
//        L.base_ci = null;
//        L.ci = null;
//        L.savedpc = new LuaCode.InstructionPtr();
//        L.errfunc = 0;
//        LuaObject.setnilvalue(gt(L));
    }
    
    
    private static func close_state(L:lua_State!) {
//        global_State g = G(L);
//        LuaFunc.luaF_close(L, L.stack[0]); // close all upvalues for this thread
//        LuaGC.luaC_freeall(L); // collect all objects
//        LuaLimits.lua_assert(g.rootgc == obj2gco(L));
//        LuaLimits.lua_assert(g.strt.nuse == 0);
//        LuaMem.luaM_freearray_GCObject(L, G(L).strt.hash, new ClassType(ClassType.TYPE_GCOBJECT));
//        LuaZIO.luaZ_freebuffer(L, g.buff);
//        freestack(L, L);
//        LuaLimits.lua_assert(g.totalbytes == CLib.GetUnmanagedSize(new ClassType(ClassType.TYPE_LG))); //typeof(LG)
//        //g.frealloc(g.ud, fromstate(L), (uint)state_size(typeof(LG)), 0);
    }
    
    //private
    public static func luaE_newthread(L:lua_State!) -> lua_State! {
//        //lua_State L1 = tostate(luaM_malloc(L, state_size(typeof(lua_State))));
//        lua_State L1 = LuaMem.luaM_new_lua_State(L, new ClassType(ClassType.TYPE_LUA_STATE));
//        LuaGC.luaC_link(L, obj2gco(L1), (byte)Lua.LUA_TTHREAD);
//        preinit_state(L1, G(L));
//        stack_init(L1, L); // init stack
//        LuaObject.setobj2n(L, gt(L1), gt(L)); // share table of globals
//        L1.hookmask = L.hookmask;
//        L1.basehookcount = L.basehookcount;
//        L1.hook = L.hook;
//        LuaDebug.resethookcount(L1);
//        LuaLimits.lua_assert(LuaGC.iswhite(obj2gco(L1)));
//        return L1;
        return nil
    }
    
    //private
    public static func luaE_freethread(L:lua_State!, L1:lua_State!) {
//        LuaFunc.luaF_close(L1, L1.stack[0]); // close all upvalues for this thread
//        LuaLimits.lua_assert(L1.openupval == null);
//        LuaConf.luai_userstatefree(L1);
//        freestack(L, L1);
//        //luaM_freemem(L, fromstate(L1));
    }
    
    public static func lua_newstate(f:lua_Alloc!, ud:Any!) -> lua_State! {
//        int i;
//        lua_State L;
//        global_State g;
//        //object l = f(ud, null, 0, (uint)state_size(typeof(LG)));
//        Object l = f.exec(new ClassType(ClassType.TYPE_LG)); //typeof(LG)
//        if (l == null) {
//        return null;
//        }
//        L = tostate(l);
//        g = ((LG)((L instanceof LG) ? L : null)).g;
//        L.next = null;
//        L.tt = Lua.LUA_TTHREAD;
//        g.currentwhite = (byte)LuaGC.bit2mask(LuaGC.WHITE0BIT, LuaGC.FIXEDBIT); //lu_byte
//        L.marked = LuaGC.luaC_white(g);
//        byte marked = L.marked; // can't pass properties in as ref - lu_byte
//        byte[] marked_ref = new byte[1];
//        marked_ref[0] = marked;
//        LuaGC.set2bits(marked_ref, LuaGC.FIXEDBIT, LuaGC.SFIXEDBIT); //ref
//        marked = marked_ref[0];
//        L.marked = marked;
//        preinit_state(L, g);
//        g.frealloc = f;
//        g.ud = ud;
//        g.mainthread = L;
//        g.uvhead.u.l.prev = g.uvhead;
//        g.uvhead.u.l.next = g.uvhead;
//        g.GCthreshold = 0; // mark it as unfinished state
//        g.strt.size = 0;
//        g.strt.nuse = 0;
//        g.strt.hash = null;
//        LuaObject.setnilvalue(registry(L));
//        LuaZIO.luaZ_initbuffer(L, g.buff);
//        g.panic = null;
//        g.gcstate = LuaGC.GCSpause;
//        g.rootgc = obj2gco(L);
//        g.sweepstrgc = 0;
//        g.sweepgc = new RootGCRef(g);
//        g.gray = null;
//        g.grayagain = null;
//        g.weak = null;
//        g.tmudata = null;
//        g.totalbytes = (long)CLib.GetUnmanagedSize(new ClassType(ClassType.TYPE_LG)); //typeof(LG) - uint
//        g.gcpause = LuaConf.LUAI_GCPAUSE;
//        g.gcstepmul = LuaConf.LUAI_GCMUL;
//        g.gcdept = 0;
//        for (i = 0; i < LuaObject.NUM_TAGS; i++) {
//        g.mt[i] = null;
//        }
//        if (LuaDo.luaD_rawrunprotected(L, new f_luaopen_delegate(), null) != 0) {
//        // memory allocation error: free partial state
//        close_state(L);
//        L = null;
//        }
//        else {
//        LuaConf.luai_userstateopen(L);
//        }
//        return L;
        return nil
    }
    
    private static func callallgcTM(L:lua_State!, ud:Any!) {
//        //UNUSED(ud);
//        LuaGC.luaC_callGCTM(L); // call GC metamethods for all udata
    }
}

public class callallgcTM_delegate: Pfunc {
    public func exec(L:lua_State!, ud:Any!) {
//        callallgcTM(L, ud);
    }
}

extension LuaState {
    public static func lua_close(L:lua_State!) {
//        L = G(L).mainthread; // only the main thread can be closed
//        LuaLimits.lua_lock(L);
//        LuaFunc.luaF_close(L, L.stack[0]); // close all upvalues for this thread
//        LuaGC.luaC_separateudata(L, 1); // separate udata that have GC metamethods
//        L.errfunc = 0; // no error function during GC metamethods
//        do {
//        // repeat until no more errors
//        L.ci = L.base_ci[0];
//        L.base_ = L.top = L.ci.base_;
//        L.nCcalls = L.baseCcalls = 0;
//        } while (LuaDo.luaD_rawrunprotected(L, new callallgcTM_delegate(), null) != 0);
//        LuaLimits.lua_assert(G(L).tmudata == null);
//        LuaConf.luai_userstateclose(L);
//        close_state(L);
    }
}
