//package kurumi;

//
// ** $Id: lzio.c,v 1.31.1.1 2007/12/27 13:02:25 roberto Exp $
// ** a generic input stream interface
// ** See Copyright Notice in lua.h
//
public class LuaZIO {
    public static let EOZ:Int = -1 // end of stream
    
    public static func char2int(c:Character) -> Int {
        for s in c.unicodeScalars {
            return Int(s.value)
        }
        return 0
    }
    
    public static func zgetc(z:ZIO!) -> Int {
//        if (z.n-- > 0) {
//        int ch = char2int(z.p.get(0));
//        z.p.inc();
//        return ch;
//        }
//        else {
//        return luaZ_fill(z);
//        }
        return 0
    }
}

public class Mbuffer {
    public var buffer:CharPtr! = CharPtr()
    public var n:Int = 0 /*uint*/
    public var buffsize:Int = 0 /*uint*/
}

extension LuaZIO {
    public static func luaZ_initbuffer(L:lua_State!, buff:Mbuffer!) {
        buff.buffer = nil
    }
    
    public static func luaZ_buffer(buff:Mbuffer!) -> CharPtr! {
        return buff.buffer
    }
    
    public static func luaZ_sizebuffer(buff:Mbuffer!) -> Int { //uint
        return buff.buffsize
    }
    
    public static func luaZ_bufflen(buff:Mbuffer!) -> Int { //uint
        return buff.n
    }
    
    public static func luaZ_resetbuffer(buff:Mbuffer!) {
        buff.n = 0;
    }
    
    public static func luaZ_resizebuffer(L:lua_State!, buff:Mbuffer!, size:Int) {
//        if (CLib.CharPtr.isEqual(buff.buffer, null)) {
//        buff.buffer = new CLib.CharPtr();
//        }
//        char[][] chars_ref = new char[1][];
//        chars_ref[0] = buff.buffer.chars;
//        LuaMem.luaM_reallocvector_char(L, chars_ref, buff.buffsize, size, new ClassType(ClassType.TYPE_CHAR)); //(int) - ref
//        buff.buffer.chars = chars_ref[0];
//        buff.buffsize = buff.buffer.chars.length; //(uint)
    }
    
    public static func luaZ_freebuffer(L:lua_State!, buff:Mbuffer!) {
        luaZ_resizebuffer(L: L, buff: buff, size: 0)
    }
}

// --------- Private Part ------------------

public class ZIO { //Zio
    public var n:Int = 0 /*uint*/            /* bytes still unread */
    public var p:CharPtr!            /* current position in buffer */
    public var reader:lua_Reader!
    public var data:Any!            /* additional data */
    public var L:lua_State!            /* Lua state (for reader) */
    
    //public class ZIO : Zio { };
}

extension LuaZIO {
    public static func luaZ_fill(z:ZIO!) -> Int {
//        int[] size = new int[1]; //uint
//        LuaState.lua_State L = z.L;
//        CLib.CharPtr buff;
//        LuaLimits.lua_unlock(L);
//        buff = z.reader.exec(L, z.data, size); //out
//        LuaLimits.lua_lock(L);
//        if (CLib.CharPtr.isEqual(buff, null) || size[0] == 0) {
//        return EOZ;
//        }
//        z.n = size[0] - 1;
//        z.p = new CLib.CharPtr(buff);
//        int result = char2int(z.p.get(0));
//        z.p.inc();
//        return result;
        return 0
    }
    
    
    public static func luaZ_lookahead(z:ZIO!) -> Int {
//        if (z.n == 0) {
//        if (luaZ_fill(z) == EOZ) {
//        return EOZ;
//        }
//        else {
//        z.n++; // luaZ_fill removed first byte; put back it
//        z.p.dec();
//        }
//        }
//        return char2int(z.p.get(0));
        return 0
    }
    
    public static func luaZ_init(L:lua_State!, z:ZIO!, reader:lua_Reader!, data:Any!) {
        z.L = L
        z.reader = reader
        z.data = data
        z.n = 0
        z.p = nil
    }
    
    
    // --------------------------------------------------------------- read ---
    public static func luaZ_read(z:ZIO!, b:CharPtr!, n:Int) -> Int { //uint - uint
//        b = new CLib.CharPtr(b);
//        while (n != 0) {
//        int m; //uint
//        if (luaZ_lookahead(z) == EOZ) {
//        return n; // return number of missing bytes
//        }
//        m = (n <= z.n) ? n : z.n; // min. between n and z.n
//        CLib.memcpy(b, z.p, m);
//        z.n -= m;
//        z.p = CLib.CharPtr.plus(z.p, m);
//        b = CLib.CharPtr.plus(b, m);
//        n -= m;
//        }
//        return 0;
        return 0
    }
    
    // ------------------------------------------------------------------------
    public static func luaZ_openspace(L:lua_State!, buff:Mbuffer!, n:Int) -> CharPtr! { //uint
//        if (n > buff.buffsize) {
//        if (n < LuaLimits.LUA_MINBUFFER) {
//        n = LuaLimits.LUA_MINBUFFER;
//        }
//        luaZ_resizebuffer(L, buff, n); //(int)
//        }
//        return buff.buffer;
        return nil
    }
}
